<?php
include "koneksi.php";
function tampil_data() {
$soal_pertanyaan="SELECT * FROM t_soal where kode_soal='$cari_soal'";
$result = mysqli_query($dbconf,$soal_pertanyaan);
$data = mysqli_fetch_array($result);
echo $data['nama_lengkap'];
}
?>