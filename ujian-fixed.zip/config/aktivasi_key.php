<?php

$host = "loftstore.co.id";
$user = "loftstore_register";
$pass = "1q@w3e4r5t6y";
$dbname = "loftstore_register";

$dbconf = mysqli_connect($host,$user,$pass,$dbname) or ("database tidak ada");

?>