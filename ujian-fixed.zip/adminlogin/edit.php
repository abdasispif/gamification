<div class="row">
        <div class="col-xs-12">
        <div class="panel panel-default">
              <div class="panel-heading">Input Admin</div>
                <div class="panel-body">
                         <form enctype="multipart/form-data" class="form-horizontal style-form" method="post" action="insert-admin.php">
                                <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Nama </label>
                                      <div class="col-sm-8">
                                          <input name="nama" type="text" class="form-control"  autofocus="on" />
                                      </div>
                                 </div>
                                 <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Password</label>
                                      <div class="col-sm-8">
                                          <input name="password" type="password" class="form-control"  autofocus="on" />
                                      </div>
                                  </div>
                                <div class="form-group">
                                      <label class="col-sm-2 col-sm-2 control-label">Foto</label>
                                      <div class="col-sm-8">
                                          <input name="nama_file" id="nama_file" type="file" class="file"  autofocus="on" />
                                      </div>
                                 </div>
                                 <div class="form-group" style="margin-bottom: 20px;">
                                      <label class="col-sm-2 col-sm-2 control-label"></label>
                                      <div class="col-sm-8">
                                          <input type="submit" value="input" class="btn btn-sm btn-primary" />&nbsp;

                                      </div>
                                </div>
                        </form>
                </div>
            </div>
      </div>
    </div>