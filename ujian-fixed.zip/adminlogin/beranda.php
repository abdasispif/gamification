<?php 
 error_reporting(E_ALL & ~E_NOTICE);
session_start();
if (empty($_SESSION['username'])){
	header('location:index.php');	
} else {
	include "../config/koneksi.php";
?>
<html>
<meta name="viewreort" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href='https://fonts.googleapis.com/css?family=Product+Sans' rel='stylesheet' type='text/css'>
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/home.css" />
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/simple-calendar.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../css/jquery.simple-calendar.js"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js" type="text/javascript"></script>
<script language="JavaScript" src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js" type="text/javascript"></script>
<script src="../js/style.js"></script>
<script>
    // datatable
    $(document).ready(function(){
    $('#myTable').DataTable();
    });
</script>
<head>
<title>Login Admin</title>
</head>

<body>
<header>
<nav class="navbar navbar-fixed-top navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
    
        <!-- hamburger --->
    <i class="fa fa-bars fa-2x navbar-btn" aria-hidden="true" data-toggle="offcanvas" role="button"></i>
    <a class="navbar-brand bg-header" href="#">ADMIN DASHBOARD</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $_SESSION['username']; ?>&nbsp;&nbsp;<span class="glyphicon glyphicon-user pull-right"></span></a>
          <ul class="dropdown-menu">
            <li><a href="logout.php">Logout <span class="glyphicon glyphicon-log-out pull-right"></span></a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
    <?php
                    } ?>
</nav>
    </header>
     <a href="logout.php">Logout</a>
    <div id="wrapper">
    <div class="overlay"></div>

  <!-- Sidebar -->
  <nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation" style="background-color: #17957B">
     
      <ul class="nav sidebar-nav">
        <li>
        
          </li>
           <li>
          <a href="beranda.php?page=dashboard">
             <i class="fa fa-dashboard"></i> <span>Dashboard</span>
           </a>
      </li>
      <li>
          <a href="beranda.php?page=dataguru">
             <i class="fa fa-group"></i> <span>Data Guru</span>
          </a>
      </li>
      <li>
          <a href="beranda.php?page=data_siswa">
             <i class="fa fa-group"></i> <span>Data Siswa</span>
          </a>
      </li>
      <li>
        <a href="?page=lihatsoal">
            <i class="fa fa-eye"></i>
            <span>Lihat Soal</span>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /#sidebar-wrapper -->

  <!-- Page Content -->
<div id="">
    <!-- <div class=""> -->
        <div class="">
        <?php
        $page = (isset($_GET['page'])) ? $_GET['page'] : "main";
        switch ($page) {
           case 'dashboard':
             include "dashboard.php";
             break;
           case 'dataguru':
             include "dataguru.php";
             break;
           case 'lihatsoal':
             include "lihatsoal.php";
             break;
           case 'lihat':
             include "lihat.php";
             break;
           case 'edit_soal':
             include "edit_soal.php";
             break;
           case 'edit_guru':
            include "edit_guru.php";
            break;
           case 'data_siswa':
            include "data_siswa.php";
            break;
           case 'edit_siswa':
            include "edit_siswa.php";
             break;
           default:
             # code...
             break;
         } 
        ?>
        </div>

    </div>
<!-- </div> -->
  <!-- /#page-content-wrapper -->
</div>
<!-- /#wrapper -->
</body>
</html>