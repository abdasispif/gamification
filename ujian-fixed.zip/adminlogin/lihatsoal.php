<div class="row">
	<div class="col-xs-12">
		<div class="">
		<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">List Soal</h4></div>
			<div class="panel-body table-responsive">
			<?php
			// $pembuat_soal = $_SESSION['username'];
			include "../config/koneksi.php";
			$tampil = mysqli_query($dbconf,"SELECT kode_soal,mata_pelajaran,pembuat_soal,waktu,status FROM t_soal GROUP BY kode_soal,mata_pelajaran,pembuat_soal,waktu,status HAVING count(*) > 0");

			?>
			<table id="myTable" class="table table-bordered">
			<thead>
			<tr>
			<th><center>No<i class="fa fa-sort"></i></center></th>
			<th><center>Kode Soal <i class="fa fa-sort"></i></center></th>
			<th><center>Mata Pelajaran <i class="fa fa-sort"></i></center></th>
			<th><center>Pembuat <i class="fa fa-sort"></i></center></th>
			<th><center>Waktu <i class="fa fa-sort"></i></center></th>
			<th><center>Status <i class="fa fa-sort"></i></center></th>
			<th><center>Tools</center></th>
			</tr>
			</thead>
			<tbody>
			<?php
			include "../chiper/cipher-function.php";
			$no = 0;
			while ($data=mysqli_fetch_array($tampil)){
			$no++;
			$view_soal  = str_replace('+','%2B',$cipher->encrypt($data['kode_soal'],$key));
			?>
			<tr>
				<td><?php echo $no;?></td>
				<td><?php echo $data['kode_soal'];?></td>
				<td><?php echo $data['mata_pelajaran'];?></td>
				<td><?php echo $data['pembuat_soal'];?></td>
				<td><?php echo $data['waktu'];?> Menit</td>
				<td align="center"><?php if ($data['status'] == 1) { echo'<span class="label label-success">Aktif</span>'; } else if ($data['status'] == 0) { echo '<span class="label label-danger">Tidak Aktif</span>'; } ?></td>
				<td>
					<center>
					<div id="thanks">
					<a class="btn btn-sm btn-primary" data-placement="bottom" name="view_soal" data-toggle="tooltip" title="Detail" href="?page=lihat&kode_soal=<?php echo $view_soal; ?>">
					<i class="fa fa-eye"></i> Lihat Soal
					</a>
					  <a class="btn btn-sm btn-info" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="aktif_status.php?kode_soal=<?php echo $data['kode_soal'];?>">
                       <i class="fa fa-check-square"></i> Aktifkan Soal
                    </a>
					</div>
					</center>
				</td>
			</tr>
			<?php } ?>
			</tbody>
			</table>
			</div>
		</div>
	</div>
</div>