<!DOCTYPE HTML>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login Admin</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/style.css" rel="stylesheet">
<!-- <link href="../css/aktivasi.css" rel="stylesheet"> -->
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $('#plsme').slideUp("slow");
        }, 900);
    });

</script>

<body>
   <div class="container" style="margin-top: 100px">
       <div class="grid">
            <div class="">
                <header class="login__header">
                    <h4>Login Admin</h4>
                </header>
                <div class="login__body">
                    <br>
                    <form method="POST" action="admin-proses.php">
                        <div class="form-group">
                            <input type="text" name="username" class="form-control" placeholder="username">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="username">
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-block btn-login" value="Sign In">
                        </div>
                        <br>
                        <footer class="login__footer">
                            <div class="col-sm-10">
                            <p>Belum punya akun? <a href="register.php">&nbsp;Register</a></p>
                            </div>
                        </footer>
                    </form>
                </div>
            </div>
       </div>
    </div>
</body>
        <script src="../js/jquery.js"></script>
        <script src="../js/bootstrap.min.js"></script>
</html>
