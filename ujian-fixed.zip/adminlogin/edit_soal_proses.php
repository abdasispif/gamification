<?php 
include "../config/koneksi.php";

$no = $_POST['no'];
$soal = $_POST['soal'];
$a = $_POST['a'];
$b = $_POST['b'];
$c = $_POST['c'];
$d = $_POST['d'];

$query_update = mysqli_query($dbconf,"UPDATE t_soal SET soal='$soal', a='$a', b='$b', c='$c', d='$d' where no ='$no'"); 
   echo "<script>alert('Berhasil dirubah'); window.location = 'beranda.php?page=lihatsoal'</script>";
?>