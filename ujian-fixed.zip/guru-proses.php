<?php
session_start();
require_once "config/koneksi.php";
$username = $_POST['username'];
$password = md5($_POST['password']);
$cekuser  = mysqli_query($dbconf,"SELECT * FROM data_guru where username = '$username' and status=1");
$result   = mysqli_fetch_array($cekuser);

if(!empty($_POST["username"])) {
    if(mysqli_num_rows($cekuser) == 0) {
            echo "<script>alert('Akun anda Belum aktif, silahkan kontak admin'); window.location = 'login-guru.php'</script>";
    } else {
    if($password <> $result['password']) {
             echo "<script>alert('Password salah'); window.location = 'login-guru.php'</script>";
    } else {
            $_SESSION['username'] = $result['username'];
            $_SESSION['nama'] = $result['nama'];
             header('location:./guru/index.php?page=dashboard');
    }
  }
} else {
    echo "<script>alert('Tolong isi kolom login'); window.location = 'login-guru.php'</script>";
}
?>