<?php 
include "../config/koneksi.php";
session_start();
if (isset($_POST['carisoal'])){
$_SESSION['cari_soal'] = $_POST['cari_soal'];
$sql = mysqli_query($dbconf,"SELECT * FROM data_soal where kode_soal='$_SESSION[cari_soal]'");
$cek = mysqli_fetch_array($sql);
if ($cek['status'] == 0){
    echo "<script>alert('Ujian Belum diaktifkan'); window.location = '/ujian/user/beranda.php'</script>";
} else {
$sql2 = mysqli_query($dbconf,"SELECT * FROM t_soal where kode_soal='$_POST[cari_soal]'"); 
$get2 = mysqli_fetch_array($sql2);
    if($sql2) {
        $_SESSION['mata_pelajaran'] = $get2['mata_pelajaran'];
        $_SESSION['waktu'] = $get2['waktu'];
        $_SESSION['level'] = $get2['level'];
        $_SESSION['soal'] = $get2['soal'];
        $_SESSION['pembuat_soal'] = $get2['pembuat_soal'];
        $_SESSION['status'] = $cek['status'];
        header('location:/ujian/index/box_info.php');
    } else {
            echo "<script>alert('Kode tidak ditemukan'); window.location = '/ujian/user/beranda.php'</script>";
    }
}
}
?>
<br>
<!-- <div class="col-md-12">
        <div class="alert alert-danger alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Selamat Datang
            <strong><?php echo $_SESSION['nama_lengkap'];?></strong>
            <br>
            Apakah anda ada Ujian hari ini? jika ada silahkan masukan kode soal yang diberikan guru anda.
        </div>
        </div> -->
<?php 
include "../config/koneksi.php";
$tampil = mysqli_query($dbconf,"SELECT * FROM user WHERE username='$_SESSION[username]'");
$sql    = mysqli_fetch_array($tampil);
?>
<div class="col-md-6 col-md-offset-3">
<div class="margin-top1">
    <div class="panel panel-default">
        <div class="panel-heading"><h4><strong>Konfirmasi Data Siswa</strong></h4></div>
        <div class="table-responsive">
            <table class="table table-bordered" style="padding: 10px;">
                <tr>
                    <td>
                        <h5><strong>NIS</strong></h5>
                        <span style="font-size: 15px;"><?php echo $_SESSION['nis'];?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Nama</strong></h5>
                        <span style="font-size: 15px;"><?php echo $sql['nama_lengkap'];?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Kelas</strong></h5>
                        <span style="font-size: 15px;"><?php echo $sql['kelas'];?>&nbsp<?php echo $sql['jurusan'];?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Jenis Kelamin</strong></h5>
                        <span style="font-size: 15px;"><?php echo $sql['jenis_kelamin'] ;?></span>
                    </td>
                </tr>
                <form method="post" action="<?php $_SERVER['PHP_SELF'];?>">
                <tr>
                    <td>
                        <h5><strong>Kode Soal</strong></h5>
                        <input type="text" name="cari_soal" class="form-control" style="width: 30%;" placeholder="Masukan Kode">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="carisoal" class="btn btn-success col-md-offset-9" style="width: 20%; border-radius: 0px;" value="Submit">
                    </td>
                </tr>
                </form>
            </table>
        </div>
    </div>
</div>
</div>