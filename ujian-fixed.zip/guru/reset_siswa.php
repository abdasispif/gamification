PHP

<?php
include '../config/koneksi.php';
// menyimpan data id kedalam variabel
$id   = $_GET['id'];
// query SQL untuk insert data
$query= "DELETE from t_nilai where id='$id'";
mysqli_query($dbconf,$query);
// mengalihkan ke halaman index.php
header("location:index.php?page=data_siswa");

?>