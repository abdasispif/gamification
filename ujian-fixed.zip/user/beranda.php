<?php 
error_reporting(E_ALL & ~E_NOTICE);
session_start();
if (empty($_SESSION['username'])){
    header('location:index.php');   
} else {
    include "../config/koneksi.php";
}
?>
<!DOCTYPE HTML>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Beranda</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<script>
    $(document).ready(function() {
        setTimeout(function() {
            $('#plsme').slideUp("slow");
        }, 900);
    });

</script>

<body>
    
<nav class="nav blue navbar-default">
  <div class="">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <p class="navbar-brand" style="color:white;">E - Learning</p>
    </div>
    <?php 
    $sql = mysqli_query($dbconf,"SELECT * FROM user WHERE username='$_SESSION[username]'");
    $get = mysqli_fetch_array($sql);
    ?>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="beranda.php" class="link-a">Home</a></li>
        <li><a href="?page=materi" class="link-a">Materi</a></li>
        <li><a class="link-a">point anda <Strong><?php echo $get['pts'];?></Strong></a></li>
        <li><a href="?page=view_nilai" class="link-a">Nilai Anda</a></li>
        <li><a href="logout.php" class="link-a">Log out</a></li>
        <!-- <li class="dropdown">
          <a href="#" class="dropdown-toggle link-a" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Menu <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="?page=cari_soal">Cari Soal</a></li>
            <li><a href="?page=view_nilai">Lihat Nilai</a></li>
            <li role="separator" class="divider"></li>
            <li><a href="logout.php">Log out</a></li>
          </ul>
        </li> -->
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div class="">
<?php
$page = $_GET['page'];
switch ($page) {
  case 'view_nilai':
    include_once "../index/view_nilai.php";
    break;
  case 'materi':
    include_once "../index/materi.php";
    break;
  case 'detail':
    include_once "../index/detail_materi.php";
    break;

  default:
    include_once "../index/box_kode.php";
    break;
}
?>
</div>
</body>
        <script src="../js/jquery.js"></script>
        <script src="../js/bootstrap.min.js"></script>
        <script src="../dist/sweetalert.min.js"></script>
</html>