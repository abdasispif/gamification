<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();
include "../config/koneksi.php";

$soal = $_SESSION['soal'];
      $no = $_SESSION['no'];

      if(isset($_POST['next'])){
 
        $_SESSION['jawab'][] = $_POST['option'];
 
        if($_POST['option'] == $soal[$no-2]['jawaban']){
 
            $_SESSION['score'] = $_SESSION['score'] + 10;
 
        }

}  if(isset($soal[$no-1])){

$sql2 = mysqli_query($dbconf,"SELECT * FROM t_nilai where username1='$_SESSION[username]' AND kode_soal='$cari_soal'");
$result2 = mysqli_fetch_array($sql2);
if(mysqli_num_rows($sql2) > 0) {
echo "<script>alert('anda telah mengikuti ulangan'); window.location = 'beranda.php'</script>";
  }
  
//set session dulu dengan nama $_SESSION["mulai"]
    if (isset($_SESSION["mulai"])) { 
        //jika session sudah ada
        $telah_berlalu = time() - $_SESSION["mulai"];
    } else { 
        //jika session belum ada
        $_SESSION["mulai"]  = time();
        $telah_berlalu      = 0;
    } 

   $sql = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE kode_soal='$_SESSION[cari_soal]' ");
   $data = mysqli_fetch_array($sql);
 
    $temp_waktu = ($data['waktu']*60) - $telah_berlalu; //dijadikan detik dan dikurangi waktu yang berlalu
    $temp_menit = (int)($temp_waktu/60);                //dijadikan menit lagi
    $temp_detik = $temp_waktu%60;                       //sisa bagi untuk detik
     
    if ($temp_menit < 60) { 
        /* Apabila $temp_menit yang kurang dari 60 meni */
        $jam    = 0; 
        $menit  = $temp_menit; 
        $detik  = $temp_detik; 
    } else { 
        /* Apabila $temp_menit lebih dari 60 menit */           
        $jam    = (int)($temp_menit/60);    //$temp_menit dijadikan jam dengan dibagi 60 dan dibulatkan menjadi integer 
        $menit  = $temp_menit%60;           //$temp_menit diambil sisa bagi ($temp_menit%60) untuk menjadi menit
        $detik  = $temp_detik;
    }

     

?>
<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Beranda</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/style.css" rel="stylesheet">
<link href="../css/BootSideMenu.css" rel="stylesheet">
<link href="../css/sweetalert.css" rel="stylesheet">
</head>

<body>
<nav class="nav blue navbar-default" style="height: 85px;">
<div class="">
<!-- Brand and toggle get grouped for better mobile display -->
<div>
<h5 class="navbar-brand" style="color:white;">E - Learning</h5>
<!-- <h5 class="nav-text-kanan" id="timer" style="margin-right: 20px; margin-top: 10px; text-align: right;"></h5> -->
<div class="nav-text-kanan" style="background-color: #212121; height: 85px; width: 230px; padding-top: 10px;">
<div class="container-fluid">
<div class="col-xs-4">
<i style="color:white;" class="fa fa-user fa-4x"></i>&nbsp;&nbsp;&nbsp;
</div>
<div class="col-xs-2">
<span style="color:white;"><?php echo $_SESSION['nama_lengkap'];?></span>
<span style="color:white;"><?php echo $_SESSION['nis'];?></span>
<a href="logout.php" style="color:blue;">Logout</a>
</div>
</div>
</div>
</div>
</div>
</div><!-- /.container-fluid -->
</nav>
<!-- <br/> -->
<div class="container-ulangan">
<div class="col-md-12">
<div class="panel" style="border-radius: 0px; padding: 0px;">
  <div class="timer">
      <div class="col-xs-5">
      <label class="font-default">SOAL NO</label>&nbsp;&nbsp;&nbsp;<label class="bg-primary" style="padding: 4px; font-size: 20px;"><?php echo $no; $_SESSION['no']++;?></label>
      </div>
      <div class="nav-text-kanan" style="padding: 5px;">
        <!-- <div style="background-color:#212121;"> -->
          <label style="background-color:#9E9E9E; color: white; padding: 4px;">Sisa waktu</label>
          <label style="background-color:#212121; margin-left: -4px; padding: 4px;" id="timer"></label>
        <!-- </div> -->
      </div>
  </div>
  <div class="font-size">
  <label>Ukuran Font</label>&nbsp;&nbsp;
  <a class="" style="font-size: 13px; font-weight: bold; text-decoration: none;" id="jfontsize-m2" href="#">A-</a>&nbsp;
  <a class="" style="font-size: 15px; font-weight: bold; text-decoration: none;" id="jfontsize-d2" href="#">A</a>&nbsp;
  <a class="" style="font-size: 17px; font-weight: bold; text-decoration: none;" id="jfontsize-p2" href="#">A+</a>&nbsp;
  </div>
<div class="panel-body">
  <div class="body-ulangan" id="questions">
      <?php
      include "../config/koneksi.php";
      $waktu_ujian = $data['waktu'];
      $tanggalUjian = date('Y-m-d');

      echo "<form method='post' action='' id='frmSoal' class=''>
          <input type='hidden' name='tanggalUjian' value='".$tanggalUjian."'>
          <input type='hidden' name='nama_lengkap' value='".$_SESSION["nama_lengkap"]."'>
          <input type='hidden' name='mata_pelajaran' value='".$_SESSION["mata_pelajaran"]."'>
          <input type='hidden' name='kode_soal' value='".$_SESSION["kode_soal"]."'>
          <input type='hidden' name='username1' value='".$_SESSION["username"]."'>
          <input type='hidden' name='level' value='".$_SESSION["level"]."'>
          <input type='hidden' name='nilai'>";
          
           // $no.". "; $_SESSION['no']++;
           $soal = $soal[$no-1]['soal'];
           // shuffle($soal);
           echo "<br><strong class='some-class-name font-default'>".$soal."</strong> <br>";
           $jawaban = $_SESSION['option'][$no-1];
 
            shuffle($jawaban);
           echo "<br>";
            
            for ($i=0; $i < 4; $i++) { ?>
            <label class="font-default some-class-name">
              <input type="radio" name="option" class="a some-class-name" value="<?php echo $jawaban[$i]; ?>" required="">
              &nbsp;&nbsp;&nbsp;<?php echo $jawaban[$i]; ?>
            </label></br>
          <?php  }
          echo '<br><hr><button name="next" class="btn btn-md btn-primary" style="width:20%; border-radius:0px;" class="btn btn-success col-xs-offset-9"> Selanjutnya </button';  
          echo "</form>"
      ?> 
    </div>
  </div>
</div>
</div>
</div>
</div>
<!--Test -->
<?php 
$soal="SELECT * FROM t_soal where kode_soal='$_SESSION[cari_soal]'";
$result = mysqli_query($dbconf,$soal);
$data = mysqli_fetch_array($result);
$jml = mysqli_num_rows($result);
?>
<div id="test">
<table class="table">
<tr>
<td><strong>Ujian :</strong>&nbsp;<span><?php echo $data['mata_pelajaran']?></span></td>
</tr>
<tr>
<td><strong>Nama :</strong>&nbsp;<span><?php echo $_SESSION['nama_lengkap'];?></span></td>
</tr>
<tr>
<td><strong>NIS :</strong>&nbsp;<span><?php echo $_SESSION['nis'];?></span></td>
</tr>
<tr>
<td><strong>Durasi :</strong>&nbsp;<span><?php echo $data['waktu'];?> Menit</span></td>
</tr>
<tr>
<td><strong>Jumlah Soal :</strong>&nbsp;<span><?php echo $jml;?></span></td>
</tr>
</table>
</div>
<!--/Test -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.js"></script>
<script type="text/javascript">
  // var button=document.getElementById("autoKlik");
  //   setInterval(function(){ 
  //       button.click();
  //    }, 20000);
</script>
<script src="http://code.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function() {
var detik   = <?= $detik; ?>;
var menit   = <?= $menit; ?>;
var jam     = <?= $jam; ?>;
function hitung() {
setTimeout(hitung,1000);
if(menit < 10 && jam == 0){
var peringatan = 'style="color:red"';
};
$('#timer').html(
'<span style="color:white;" align="center"'+peringatan+'>' + jam + ' : ' + menit + ' : ' + detik + '</span>'
);
detik --;
if(detik < 0) {
detik = 59;
menit --;
if(menit < 0) {
    menit = 59;
    jam --;
    if(jam < 0) { 
        clearInterval(hitung); 
        /** Variable yang digunakan untuk submit secara otomatis di Form */
        var frmSoal = document.getElementById("frmSoal"); 
        alert('Waktu Anda telah habis, Jika ingin mencoba lagi silahkan dihapus dulu SESSION browser anda');
        frmSoal.submit(); 
    } 
} 
} 
}           
hitung();
});
</script>
<script type="text/javascript">
    // $(document).ready(function() {
    //     function disableBack() { window.history.forward() }

    //     window.onload = disableBack();
    //     window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    // });
</script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/sweetalert.min.js"></script>
<script type="text/javascript" language="javascript" src="../js/jfontsize/jstorage.js"></script>
<script type="text/javascript" language="javascript" src="../js/jfontsize/jquery.jfontsize-2.0.js"></script>
<script src="../js/BootSideMenu.js"></script>
<script src="../js/style.js"></script>
<script type="text/javascript">

</script>
</body>
</html>
<?php } else {
    header('location:ulangan-cek.php');
} ?>