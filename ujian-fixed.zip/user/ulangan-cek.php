<html>
<link href="../css/sweetalert.css" rel="stylesheet">
<script src="../js/sweetalert.min.js"></script>
<script src="../js/jquery.js"></script>
<?php
include '../config/koneksi.php';
session_start();

$tanggalUjian = date('Y-m-d');
$nama_lengkap = $_SESSION['nama_lengkap'];
$mata_pelajaran = $_SESSION['mata_pelajaran'];
$kode_soal = $_SESSION['cari_soal'];
$peserta    = $_SESSION['username'];
$level = $_SESSION['level'];

$jawab = $_SESSION['jawab'];
$i = 0;
$benar = $salah = 0;
$sql = mysqli_query($dbconf,"select * from t_soal where kode_soal = '$_SESSION[cari_soal]'");
$jml_soal = mysqli_num_rows($sql);

while($key = mysqli_fetch_array($sql)){
 if ($jawab[$i] == $key['jawaban']) {
    $benar++;
}else{
    $salah++;
}
  $i++;
} 

$total = 100/$jml_soal*$benar; 
$hasil = number_format($total,1);

$fetch = mysqli_query($dbconf,"SELECT * FROM user WHERE nama_lengkap='$_SESSION[nama_lengkap]'");
$get = mysqli_fetch_array($fetch);
$add_pts = $get['pts'] + 10;
$hasil2 = $add_pts;

$sql = mysqli_query($dbconf,"UPDATE user SET pts='$hasil2' WHERE nama_lengkap='$_SESSION[nama_lengkap]'");


$sql = "INSERT INTO t_nilai (tanggalUjian,nama_lengkap,mata_pelajaran,kode_soal,username1,nilai,level,pts) value ('$tanggalUjian','$nama_lengkap','$mata_pelajaran','$kode_soal','$peserta','$hasil',$level,$hasil2)";


if(!empty($jawab)){

  if (mysqli_multi_query($dbconf,$sql)) {
    echo"<script type='text/javascript'>
                    setTimeout(function () { 
                        swal({
                        title: 'Selesai',
                        text:  '',
                        type: 'success',
                        timer: 5000,
                        showConfirmButton: true
                    });  
                },10); 
                window.setTimeout(function(){ 
                window.location.replace('beranda.php');
            } ,5000);  
            </script>";  
 
  } else {
     echo "<script>alert('GAGAL'); window.location = 'ulangan.php'</script>"; 
  }
} else {
    echo"<script type='text/javascript'>
                    setTimeout(function () { 
                        swal({
                        title: 'Tolong isi',
                        text:  'Soal yang disediakan',
                        type: 'warning',
                        timer: 5000,
                        showConfirmButton: true
                    });  
                },10); 
                window.setTimeout(function(){ 
                window.location.replace('ulangan.php');
            } ,5000); 
            </script>";                }

// $tanggalUjian = date('Y-m-d');
// echo ''.$tanggalUjian.'<br>';
// echo ''.$_SESSION['mata_pelajaran'].'<br>';
// echo ''.$_SESSION['nama_lengkap'].'<br>';
// echo ''.$_SESSION['cari_soal'].'<br>';
// echo ''.$_SESSION['username'].'<br>';
// echo ''.$_SESSION['nis'].'<br>';
?>

<!-- <a href="logout.php">Kembali</a> -->
</html>