<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "ujian";

$dbconf = mysqli_connect($host,$user,$pass,$dbname) or ("database tidak ada");

?>
