<!DOCTYPE html>
<html>
<head>
<title>Aktivasi</title>
<link rel="stylesheet" type="text/css" href="css/aktivasi.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<?php
$waktu=gmdate("H:i",time()+7*3600);
$t=explode(":",$waktu);
$jam=$t[0];
$menit=$t[1];

if ($jam >= 00 and $jam < 10 ){
if ($menit >00 and $menit<60){
$ucapan="Selamat Pagi";
}
}else if ($jam >= 10 and $jam < 15 ){
if ($menit >00 and $menit<60){
$ucapan="Selamat Siang";
}
}else if ($jam >= 15 and $jam < 18 ){
if ($menit >00 and $menit<60){
$ucapan="Selamat Sore";
}
}else if ($jam >= 18 and $jam <= 24 ){
if ($menit >00 and $menit<60){
$ucapan="Selamat Malam";
}
}else {
$ucapan="Error";
}
?>
<body>
<div class="container">
<div class="row">
	<div class="col-md-12">
		<div class="body-warning">
			<h1 style="font-size: 70px; color: white;">Halo <?php echo $ucapan;?></h1>
			<p style="font-size: 30px; color: white;">Jika anda berada dihalaman ini, server ini tidak terdaftar diaplikasi ini. <br>
			Untuk melakukan aktivasi, silahkan kontak developer atau support center.
			</p>
			<!-- <a href="" class="btn btn-outline-light btn-lg"><i class="fa fa-user"></i>&nbsp;&nbsp;Kontak Developer</a> -->
			<button type="button" class="btn btn-lg btn-outline-light" data-toggle="modal" data-target="#exampleModalCenter"><i class="fa fa-user"></i> Kontak Developer</button>
		</div>
	</div>
</div>
<!-- modal developer -->
<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="exampleModalLongTitle">Developer Contact</h1>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<h2></h2>
		<h4><i class="fa fa-whatsapp fa-1x"></i>&nbsp;085714169483 Apsyadira</h4>
		<h4><i class="fa fa-instagram fa-1x"></i>&nbsp;@apsyadiraa</h4>
      </div>
      <div class="modal-footer">
       <!--  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button> -->
        <h4>Copyright &copy 2018 Apsyadira</h4>
      </div>
    </div>
  </div>
</div>
<!-- end modal -->
<footer class="">
	<center>
		<!-- <h4 style="color:white;">Copyright &copy 2018 Apsyadira</h4> -->
	</center>
</footer>
</div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>