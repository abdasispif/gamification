<div class="row">
  <div class="col-md-12">
    <div class="">
        <div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">Data Guru</h4></div>
        <div class="panel-body table-responsive">
          <table id="myTable" class="table table-bordered">
            <thead>
              <tr>
                <td>No</td>
                <td>Nama</td>
                <td>Username</td>
                <td>Password</td>
                <td>Status</td>
                <td align="center">Tool</td>
              </tr>
            </thead>
            <tbody>
            <?php
          // $pembuat_soal = $_SESSION['username'];
          include "../config/koneksi.php";
          include "../chiper/cipher-function.php";
          $no = 0;
          $tampil = mysqli_query($dbconf,"SELECT * FROM data_guru");
          while($data = mysqli_fetch_array($tampil)) {
          $id = str_replace('+','%2B',$cipher->encrypt($data['id'],$key));
          $no++;
          ?>
          <tr>
            <td><?php echo $no;?></td>
            <td><?php echo $data['nama'];?></td>
            <td><?php echo $data['username'];?></td>
            <td><?php echo substr($data['password'],24);?></td>
            <td align="center"><?php if ($data['status'] == 1) { echo'<span class="label label-success">Aktif</span>'; } else if ($data['status'] == 0) { echo '<span class="label label-danger">Tidak Aktif</span>'; } ?></td>
            <td align="center">
              <a href="beranda.php?page=edit_guru&&id=<?php echo $id;?>" data-toggle="tooltip" data-placement="bottom" title="Edit Akun" onclick="return confirm('Apakah anda yakin ingin merubah akun ini?')" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i>Edit</a>
              <a href="reset_siswa.php?id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Hapus Akun" onclick="return confirm('Apakah anda yakin ingin menghapus akun ini?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>Hapus</a>
              <?php if ($data['status'] == 1) { ?>
              <a href="status.php?page=nonaktif&id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Nonaktifkan" onclick="return confirm('Apakah anda yakin ingin menghapus akun ini?')"  class="btn btn-primary btn-sm"><i class="fa fa-check"></i>Nonaktif</a> 
              <?php } else { ?>             
              <a href="status.php?page=aktif&id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Aktifkan"   class="btn btn-success btn-sm"><i class="fa fa-check"></i>Aktifkan</a>
              <?php } ?>         
              <!-- <a href="" class="btn btn-primary btn-sm"></a>              -->
            </td>
          </tr>
          <?php } ?>
            </tbody>
          </table>
        </div>
    </div>
  </div>
</div>