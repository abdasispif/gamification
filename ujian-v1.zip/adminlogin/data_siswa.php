<div class="row">
  <div class="col-md-12">
    <div class="">
        <div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">Data Siswa</h4></div>
        <div class="panel-body table-responsive">
          <table id="myTable" class="table table-bordered">
            <thead>
              <tr>
                <td>No</td>
                <td>Nama Lengkap</td>
                <td>Jenis Kelamin</td>
                <td>NIS</td>
                <td>Kelas</td>
                <td>Jurusan</td>
                <td>Username</td>
                <td>Password</td>
                <td>Status</td>
                <td align="center">Tool</td>
              </tr>
            </thead>
            <tbody>
            <?php
          // $pembuat_soal = $_SESSION['username'];
          include "../config/koneksi.php";
          include "../chiper/cipher-function.php";
          $no = 0;
          $tampil = mysqli_query($dbconf,"SELECT * FROM user");
          while($data = mysqli_fetch_array($tampil)) {
          $id = str_replace('+','%2B',$cipher->encrypt($data['id'],$key));
          $no++;
          ?>
          <tr>
            <td><?php echo $no;?></td>
            <td><?php echo $data['nama_lengkap'];?></td>
            <td><?php echo $data['jenis_kelamin'];?></td>
            <td><?php echo $data['nis'];?></td>
            <td><?php echo $data['kelas'];?></td>
            <td><?php echo $data['jurusan'];?></td>
            <td><?php echo $data['username'];?></td>
            <td><?php echo substr($data['password'],20);?></td>
            <td align="center"><?php if ($data['status'] == 1) { echo'<span class="label label-success">Aktif</span>'; } else if ($data['status'] == 0) { echo '<span class="label label-danger">Tidak Aktif</span>'; } ?></td>
            <td align="center">
              <a href="beranda.php?page=edit_siswa&&id=<?php echo $id;?>" data-toggle="tooltip" data-placement="bottom" title="Edit Akun" onclick="return confirm('Apakah anda yakin ingin merubah akun ini?')" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
              <a href="reset_siswa.php?id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Hapus Akun" onclick="return confirm('Apakah anda yakin ingin menghapus akun ini?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a> 
              <?php if ($data['status'] == 1) { ?>
              <a href="status.php?page=sisak&id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Nonaktifkan" onclick="return confirm('Apakah anda yakin ingin menghapus akun ini?')"  class="btn btn-primary btn-sm"><i class="fa fa-check"></i></a> 
              <?php } else { ?>             
              <a href="status.php?page=sisnon&id=<?php echo $data['id'];?>" data-toggle="tooltip" data-placement="bottom" title="Aktifkan"   class="btn btn-success btn-sm"><i class="fa fa-check"></i></a>
              <?php } ?>
            </td>
          </tr>
          <?php } ?>
            </tbody>
          </table>
        </div>
    </div>
  </div>
</div>
