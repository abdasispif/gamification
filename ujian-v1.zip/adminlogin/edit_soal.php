
<div class="row">
	<div class="col-md-12">
	<div class="">
		<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">List Soal</h4></div>
			<div class="panel-body">
			<?php 
			error_reporting(E_ALL & ~E_NOTICE);
			include "../config/koneksi.php";
			include "../chiper/cipher-function.php";
			$nosoal = $cipher->decrypt($_GET['no'],$key);
			$query = mysqli_query($dbconf,"SELECT * FROM t_soal where no='$nosoal'");
			while ($data = mysqli_fetch_array($query)){
			?>
			<form class="form-horizontal" action="edit_soal_proses.php" method="post">
            <div class="form-group">
            	<input type="hidden" name="no" value="<?php echo $data['no'];?>">
                <label for="inputEmail3" class="col-sm-2 control-label">Soal</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="soal" rows="3"><?php echo $data['soal'];?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban A</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="a" rows="3"><?php echo $data['a'];?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban B</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="b" rows="3"><?php echo $data['b'];?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban C</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="c" rows="3"><?php echo $data['c'];?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban D</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="d" rows="3"><?php echo $data['d'];?></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Kunci Jawaban</label>
                <div class="col-sm-6">
                A <input type="radio" name="jawaban" value="A">&nbsp
                B <input type="radio" name="jawaban" value="B">&nbsp 
                C <input type="radio" name="jawaban" value="C">&nbsp 
                D <input type="radio" name="jawaban" value="D">&nbsp 
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default">Buat</button>
                </div>
            </div>
        </form>
        <?php } ?>
			</div>
	</div>
</div>