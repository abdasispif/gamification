
<div class="row">
	<div class="col-md-12">
	<div class="">
		<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">Edit Akun Guru</h4></div>
			<div class="panel-body">
			<?php 
			error_reporting(E_ALL & ~E_NOTICE);
			include "../config/koneksi.php";
			include "../chiper/cipher-function.php";
			$id = $cipher->decrypt($_GET['id'],$key);
			$query = mysqli_query($dbconf,"SELECT * FROM data_guru where id='$id'");
			while ($data = mysqli_fetch_array($query)){
			?>
			<form class="form-horizontal" action="edit_soal_guru.php" method="post">
            <div class="form-group">
            	<input type="hidden" name="id" value="<?php echo $data['id'];?>">
                <label for="inputEmail3" class="col-sm-2 control-label">Nama</label>
                <div class="col-sm-6">
                    <input type="text" name="nama" class="form-control" value="<?php echo $data['nama'];?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-6">
                    <input type="text" name="username" class="form-control" value="<?php echo $data['username'];?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
                <div class="col-sm-6">
                    <input type="password" name="password" class="form-control" value="<?php echo $data['password'];?>">
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default">Buat</button>
                </div>
            </div>
        </form>
        <?php } ?>
			</div>
	</div>
</div>