<?php
require_once("../config/koneksi.php"); // panggil koneksi database
$page = $_GET['page'];

if ($page == 'aktif'){

$id = $_GET['id']; // ambil paramater id yang diambil dari halaman index.php tadi
$update = "UPDATE data_guru SET status = '1' where id=$id";// update table admin , lalu diubah statusnya tadi dari N menjadi Y berdasarkan id yang dipilih
$query = mysqli_query($dbconf,$update); // eksekusi query nya
if($query){ // cek kondisi jika sudah benar maka akan menuju ke halaman index.php dan statusnya berbubah jadi aktif 
	header("location:beranda.php?page=dataguru");
}
else{ // jika salah maka tampilkan pesan error
	echo "<b class='alert alert-danger'> Gagal update data </b>";
}

} if ($page == 'nonaktif'){
$id = $_GET['id']; // ambil paramater id yang diambil dari halaman index.php tadi
$update = "UPDATE data_guru SET status = '0' where id=$id";// update table admin , lalu diubah statusnya tadi dari N menjadi Y berdasarkan id yang dipilih
$query = mysqli_query($dbconf,$update); // eksekusi query nya
if($query){ // cek kondisi jika sudah benar maka akan menuju ke halaman index.php dan statusnya berbubah jadi aktif 
	header("location:beranda.php?page=dataguru");
}
else{ // jika salah maka tampilkan pesan error
	echo "<b class='alert alert-danger'> Gagal update data </b>";
}
}

if ($page == 'sisak'){

$id = $_GET['id']; // ambil paramater id yang diambil dari halaman index.php tadi
$update = "UPDATE user SET status = '1' where id=$id";// update table admin , lalu diubah statusnya tadi dari N menjadi Y berdasarkan id yang dipilih
$query = mysqli_query($dbconf,$update); // eksekusi query nya
if($query){ // cek kondisi jika sudah benar maka akan menuju ke halaman index.php dan statusnya berbubah jadi aktif 
	header("location:beranda.php?page=data_siswa");
}
else{ // jika salah maka tampilkan pesan error
	echo "<b class='alert alert-danger'> Gagal update data </b>";
}
}

if ($page == 'sisnon'){

$id = $_GET['id']; // ambil paramater id yang diambil dari halaman index.php tadi
$update = "UPDATE user SET status = '1' where id=$id";// update table admin , lalu diubah statusnya tadi dari N menjadi Y berdasarkan id yang dipilih
$query = mysqli_query($dbconf,$update); // eksekusi query nya
if($query){ // cek kondisi jika sudah benar maka akan menuju ke halaman index.php dan statusnya berbubah jadi aktif 
	header("location:beranda.php?page=data_siswa");
}
else{ // jika salah maka tampilkan pesan error
	echo "<b class='alert alert-danger'> Gagal update data </b>";
}
}
if ($page == 'edit_admin'){
	$id = $_POST['id'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$adm = mysqli_query($dbconf,"UPDATE admin SET username='$username',password='$password' WHERE id='$id'");
	if ($adm) {
		echo "<script>alert('Data berhasil dirubah'); window.location = 'beranda.php?page=dashboard'</script>";
	} else {
		echo "<script>alert('gagal'); window.location = 'beranda.php?page=dashboard'</script>";
	}
}
if ($page == 'edit_judul'){
	$id = $_POST['id'];
	$judul = $_POST['judul'];
	$adm = mysqli_query($dbconf,"UPDATE t_judul SET judul='$judul' WHERE id='$id'");
	if ($adm) {
		echo "<script>alert('Data berhasil dirubah'); window.location = 'beranda.php?page=dashboard'</script>";
	} else {
		echo "<script>alert('gagal'); window.location = 'beranda.php?page=dashboard'</script>";
	}
}
?>