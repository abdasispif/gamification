<?php 
include "../config/koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = md5($_POST['password']);

$query_update = mysqli_query($dbconf,"UPDATE data_guru SET nama='$nama',username='$username',password='$password' where id='$id'"); 
   echo "<script>alert('Berhasil dirubah'); window.location = 'beranda.php?page=dataguru'</script>";
?>