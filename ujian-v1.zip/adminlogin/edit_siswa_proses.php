<?php 
include "../config/koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama_lengkap'];
$jk = $_POST['jenis_kelamin'];
$nis = $_POST['nis'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];
$username = $_POST['username'];
$password = md5($_POST['password']);

$query_update = mysqli_query($dbconf,"UPDATE user SET nama_lengkap='$nama',jenis_kelamin='$jk',nis='$nis',kelas='$kelas',jurusan='$jurusan',username='$username',password='$password' where id='$id'"); 
   echo "<script>alert('Berhasil dirubah'); window.location = 'beranda.php?page=data_siswa'</script>";
?>