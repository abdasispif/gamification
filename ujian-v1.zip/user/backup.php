<html>
<link href="../css/sweetalert.css" rel="stylesheet">
<script src="../js/sweetalert.min.js"></script>
<script src="../js/jquery.js"></script>

<?php
$page = $_GET['a'];
if ($page == 'proses'){
include "../config/koneksi.php";
if(isset($_POST['submit'])){
$tanggalUjian = $_POST['tanggalUjian'];
$nama_lengkap = $_POST['nama_lengkap'];
$mata_pelajaran = $_POST['mata_pelajaran'];
$kode_soal = $_POST['kode_soal'];
$peserta    = $_POST['username1'];
$level = $_POST['level'];


// foreach ($pilihan_user as $nomor => $nilai){
  
//   $data_soal = mysqli_query($dbconf,"SELECT * FROM t_soal where no='$nomor'");
//   $data_jawab = mysqli_fetch_assoc($data_soal);

//   if($data_jawab['jawaban'] == $nilai){
//     $benar = $benar + 1;
//   } else {
//     $salah = $salah + 1;
//   }

//   $result = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE kode_soal='$kode_soal'");
//   $jumlah_soal = mysqli_num_rows($result);
//   $score = 100/$jumlah_soal*$benar;
//   $hasil = $score;
// }

$fetch = mysqli_query($dbconf,"SELECT * FROM user WHERE nama_lengkap='$nama_lengkap'");
$get = mysqli_fetch_array($fetch);
$add_pts = $get['pts'] + 10;
$hasil2 = $add_pts;

$sql = mysqli_query($dbconf,"UPDATE user SET pts='$hasil2' WHERE nama_lengkap='$nama_lengkap'");


$sql = "INSERT INTO t_nilai (tanggalUjian,nama_lengkap,mata_pelajaran,kode_soal,username1,nilai,level,pts) value ('$tanggalUjian','$nama_lengkap','$mata_pelajaran','$kode_soal','$peserta','$hasil',$level,$hasil2)";


if(!empty($_POST['pilihan'])){

  if (mysqli_multi_query($dbconf,$sql)) {
    echo"<script type='text/javascript'>
                    setTimeout(function () { 
                        swal({
                        title: 'Selesai',
                        text:  '',
                        type: 'success',
                        timer: 5000,
                        showConfirmButton: true
                    });  
                },10); 
                window.setTimeout(function(){ 
                window.location.replace('beranda.php');
            } ,5000);  
            </script>";  
 
  } else {
     echo "<script>alert('GAGAL'); window.location = 'ulangan.php'</script>"; 
  }
} else {
    echo"<script type='text/javascript'>
                    setTimeout(function () { 
                        swal({
                        title: 'Tolong isi',
                        text:  'Soal yang disediakan',
                        type: 'warning',
                        timer: 5000,
                        showConfirmButton: true
                    });  
                },10); 
                window.setTimeout(function(){ 
                window.location.replace('ulangan.php');
            } ,5000); 
            </script>";                }
}
}
?>
</html>