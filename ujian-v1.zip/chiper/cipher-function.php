<?php
require_once "cipher-class.php";
$cipher = new Cipher(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);
$key = "ShindyPr4sT!k4";

?>