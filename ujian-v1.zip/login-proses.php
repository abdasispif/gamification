<?php
session_start();
require_once "config/koneksi.php";

$username = $_POST['username'];
$password = md5($_POST['password']);
$cekuser  = mysqli_query($dbconf,"SELECT * FROM user where username = '$username'");
$result   = mysqli_fetch_array($cekuser);

if(!empty($_POST["username"])) {
    if(mysqli_num_rows($cekuser) == 0) {
            echo "<script>alert('Username tidak ada'); window.location = 'index.php'</script>";
    } else {
    if($password <> $result['password']) {
             echo "<script>alert('Password salah'); window.location = 'index.php'</script>";
    } else {
            $_SESSION['nama_lengkap'] = $result['nama_lengkap'];
            $_SESSION['username'] = $result['username'];
            $_SESSION['jenis_kelamin'] = $result['jenis_kelamin'];
            $_SESSION['nis'] = $result['nis'];
            $_SESSION['kelas'] = $result['kelas'];
            $_SESSION['jurusan'] = $result['jurusan'];
             header('location:/ujian/user/beranda.php?page=box_kode');
    }
  }
} else {
    echo "<script>alert('Tolong isi kolom login'); window.location = '/ujian/'</script>";
}
?>