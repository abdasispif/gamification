-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Mar 2018 pada 06.36
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ujian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(22) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(3, 'apsyadira', '1b0c21b75c110472d03ad1c91c08b14e'),
(4, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_guru`
--

CREATE TABLE `data_guru` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_guru`
--

INSERT INTO `data_guru` (`id`, `nama`, `username`, `password`, `status`) VALUES
(1, 'syarif123', 'syarif', '8daa2f003d41f1ea865c1503b3d99d3d', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_soal`
--

CREATE TABLE `data_soal` (
  `id` int(22) NOT NULL,
  `kode_soal` varchar(22) NOT NULL,
  `pembuat_soal` varchar(22) NOT NULL,
  `mata_pelajaran` varchar(22) NOT NULL,
  `level` varchar(22) NOT NULL,
  `waktu` varchar(22) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data_soal`
--

INSERT INTO `data_soal` (`id`, `kode_soal`, `pembuat_soal`, `mata_pelajaran`, `level`, `waktu`, `status`) VALUES
(4, '5c89ff4', 'syarif', 'Bongkar Komputer', '1', '120', 1),
(6, '078c0cd', 'syarif', 'Pemrograman Web', '1', '120', 0),
(8, 'def6842', 'syarif', 'testing doang', '1', '90', 0),
(9, 'a8300df', 'admin', 'Bahasa inggris', '1', '15', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasukan_spp`
--

CREATE TABLE `pemasukan_spp` (
  `id` int(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `tgl_pembayaran` varchar(20) NOT NULL,
  `jumlah` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `timer`
--

CREATE TABLE `timer` (
  `id` int(11) NOT NULL,
  `waktu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `timer`
--

INSERT INTO `timer` (`id`, `waktu`) VALUES
(1, 30);

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_judul`
--

CREATE TABLE `t_judul` (
  `id` int(22) NOT NULL,
  `judul` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_judul`
--

INSERT INTO `t_judul` (`id`, `judul`) VALUES
(1, 'apsyadira');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_materi`
--

CREATE TABLE `t_materi` (
  `id` int(22) NOT NULL,
  `pembuat_materi` varchar(22) NOT NULL,
  `judul_materi` varchar(22) NOT NULL,
  `isi_materi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_materi`
--

INSERT INTO `t_materi` (`id`, `pembuat_materi`, `judul_materi`, `isi_materi`) VALUES
(8, 'syarif', 'Jaringan Nirkabel', '1.	Konsep yang dibahas dalam gerak periodik benda\n2.	Pencampuran dua sinyal menjadi satu sinyal\n3.	Modulasi\n4.	WiFi\n5.	WiMAX\n6.	Jaringan komunikasi wireless\n7.	Satuan frekuensi\n8.	Modulasi AM\n9.	WPAN\n10.	Standart wireless\n11.	Syarat standar survey perancangan jaringan wireless \n12.	Topologi jaringan nirkabel\n13.	ASK dalam modulasi digital\n14.	Tujuan modulasi\n15.	Fungsi dari access point\n16.	Peralatan yang dibutuhkan untuk koneksi antara jaringan\n17.	Noise\n18.	Jaringan komputer yang menggunakan gelombang radio sebagai media transmisi data\n19.	Node yang telah dikonfigurasi secara khusus pada sebuah WLAN\n20.	Device yang berfungsi untuk meneruskan paket-paket dari sebuah network ke network\n21.	Hubungan antara panjang gelombang, frequensi dan kecepatan gelombang\n22.	Standart 802.11b\n23.	FSK dalam modulasi digital');

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_nilai`
--

CREATE TABLE `t_nilai` (
  `id` int(20) NOT NULL,
  `tanggalUjian` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_lengkap` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mata_pelajaran` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kode_soal` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username1` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nilai` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pts` varchar(22) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `t_soal`
--

CREATE TABLE `t_soal` (
  `no` int(11) NOT NULL,
  `kode_soal` varchar(30) NOT NULL,
  `mata_pelajaran` varchar(20) NOT NULL,
  `pembuat_soal` varchar(22) NOT NULL,
  `level` varchar(22) NOT NULL,
  `point_level` varchar(22) NOT NULL,
  `waktu` int(11) DEFAULT NULL,
  `soal` text NOT NULL,
  `a` varchar(1000) NOT NULL,
  `b` varchar(1000) NOT NULL,
  `c` varchar(1000) NOT NULL,
  `d` varchar(1000) NOT NULL,
  `jawaban` varchar(1000) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `t_soal`
--

INSERT INTO `t_soal` (`no`, `kode_soal`, `mata_pelajaran`, `pembuat_soal`, `level`, `point_level`, `waktu`, `soal`, `a`, `b`, `c`, `d`, `jawaban`, `status`) VALUES
(1, '5c89ff4', 'Bongkar Komputer', 'syarif', '1', '10', 120, 'Windows XP SP3 merupakan salah satu nama produk dari â€¦', 'linux', 'ubuntu', 'windows', 'android', 'windows', 0),
(2, '5c89ff4', 'Bongkar Komputer', 'syarif', '1', '10', 120, 'Memori komputer berguna untuk â€¦', 'Penyimpanan data sementara', 'Melakukan setup OS', 'Random Access Memory', 'Semua benar', 'Semua benar', 0),
(3, 'def6842', 'testing doang', 'syarif', '1', '10', 90, 'asdsfsdf', 'jklfjslkj', 'lkjklsfj', 'lkjklfjskl', 'dfsdfsdfsd', 'lkjklsfj', 0),
(4, '5c89ff4', 'Bongkar Komputer', 'syarif', '1', '', 120, 'Apakah yang dimaksud dengan upgrade komputer?', 'Mengganti semua komponen komputer', 'Mengganti sebagian komponen komputer dengan spesifikasi yang lebih tinggi', ' Mengganti sebagian komponen komputer dengan spesifikasi yang lebih rendah', 'Mengganti sebagian komponen komputer karena kerusakan hardware', 'Mengganti sebagian komponen komputer dengan spesifikasi yang lebih tinggi', 0),
(5, 'a8300df', 'Bahasa inggris', 'admin', '1', '', 15, 'What the mean the word " lost" ?', 'Hilang', 'Kalah', 'Menang', 'Kiri', 'Hilang', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(100) NOT NULL,
  `nama_lengkap` varchar(30) NOT NULL,
  `jenis_kelamin` varchar(22) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `jurusan` varchar(20) NOT NULL,
  `pts` int(22) NOT NULL,
  `status` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `nama_lengkap`, `jenis_kelamin`, `username`, `password`, `nis`, `kelas`, `jurusan`, `pts`, `status`) VALUES
(18, 'apsyadira', 'Laki - laki', 'apsya', 'e3a7459a7ee15552b17c5759b693cf31', '25062012', 'XII', 'TKJ', 0, 1),
(22, 'Arina', 'Perempuan', 'arina', '39ae638603d245e33ec73d9176ca5f', '250613', 'XII', 'Perawatan', 0, 1),
(23, 'elang egi', 'Laki - laki', 'elang', '6d466a5519f78c700659bdd212001a', '250614', 'XII', 'TSM', 0, 1),
(25, 'Irdhina Lestari', 'Perempuan', 'irdhina', '28dfeb6ce93964c2f4491c8fa95fd6e8', '25062099', 'XII', 'Perawatan', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_guru`
--
ALTER TABLE `data_guru`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_soal`
--
ALTER TABLE `data_soal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pemasukan_spp`
--
ALTER TABLE `pemasukan_spp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `timer`
--
ALTER TABLE `timer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_judul`
--
ALTER TABLE `t_judul`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_materi`
--
ALTER TABLE `t_materi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_nilai`
--
ALTER TABLE `t_nilai`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `t_soal`
--
ALTER TABLE `t_soal`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `data_guru`
--
ALTER TABLE `data_guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `data_soal`
--
ALTER TABLE `data_soal`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pemasukan_spp`
--
ALTER TABLE `pemasukan_spp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `timer`
--
ALTER TABLE `timer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_judul`
--
ALTER TABLE `t_judul`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `t_materi`
--
ALTER TABLE `t_materi`
  MODIFY `id` int(22) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `t_nilai`
--
ALTER TABLE `t_nilai`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `t_soal`
--
ALTER TABLE `t_soal`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
