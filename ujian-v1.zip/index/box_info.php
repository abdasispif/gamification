<?php 
error_reporting(E_ALL & ~E_NOTICE);
session_start();
include "../config/koneksi.php";

if (isset($_POST['cari'])){
    $sql2 = mysqli_query($dbconf,"SELECT * FROM t_nilai where username1='$_SESSION[username]' AND kode_soal='$_SESSION[cari_soal]'");
    $result2 = mysqli_fetch_array($sql2);
        if(mysqli_num_rows($sql2) > 0) {
        echo "<script>alert('anda telah mengikuti ulangan'); window.location = '../user/beranda.php'</script>";

        } else {
        
        $query = mysqli_query($dbconf,"select * from t_soal where kode_soal='$_SESSION[cari_soal]'");
         
            //$_SESSION['soal'] = mysql_fetch_array($query);
         
            $_SESSION['soal'] = array();
         
            $_SESSION['no'] = 1;
         
            $_SESSION['score'] = 0;
         
            $_SESSION['option'] = array();
         
            $_SESSION['jawab'] = array();
         
            $i=0;
         
            while($row = mysqli_fetch_assoc($query)){
         
                $_SESSION['soal'][] = $row;
         
                $_SESSION['option'][] = array($_SESSION['soal'][$i]['a'], $_SESSION['soal'][$i]['b'], $_SESSION['soal'][$i]['c'], $_SESSION['soal'][$i]['d']);
         
                $i++;
         
            }
         
            if(isset($_SESSION['soal'])){
         
                header("location:../user/ulangan.php");
         
            }
                }
}

?>
<!DOCTYPE HTML>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Beranda</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/style.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/sweetalert.css">
<body>
<nav class="nav blue navbar-default" style="height: 85px;">
<div class="">
<!-- Brand and toggle get grouped for better mobile display -->
<div>
<h5 class="navbar-brand" style="color:white;">E - Learning</h5>
<!-- <h5 class="nav-text-kanan" id="timer" style="margin-right: 20px; margin-top: 10px; text-align: right;"></h5> -->
<div class="nav-text-kanan" style="background-color: #212121; height: 85px; width: 230px; padding-top: 10px;">
<div class="container-fluid">
<div class="col-xs-4">
<i style="color:white;" class="fa fa-user fa-4x"></i>&nbsp;&nbsp;&nbsp;
</div>
<div class="col-xs-2">
<span style="color:white;"><?php echo $_SESSION['nama_lengkap'];?></span>
<span style="color:white;"><?php echo $_SESSION['nis'];?></span>
<a href="logout.php" style="color:blue;">Logout</a>
</div>
</div>
</div>
</div>
</div>
</div><!-- /.container-fluid -->
</nav>
<br>
<div class="container-fluid">
    <div class="col-md-7">
        <div class="panel panel-default">
            <div class="panel-heading"><h4>Konfirmasi Ujian</h4></div>
            <div class="table-responsive">
            <table class="table">
                <table class="table table-bordered" style="padding: 10px;">
                <tr>
                    <td>
                        <h5><strong>Nama Ujian</strong></h5>
                        <span style="font-size: 15px;"><?php echo $_SESSION['mata_pelajaran'];?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Status Ujian</strong></h5>
                        <span style="font-size: 15px;"><?php if($_SESSION['status'] == 1) { echo "Aktif"; } else if ($_SESSION['status']==0){ echo "Tidak Aktif";};?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Waktu Ujian</strong></h5>
                        <span style="font-size: 15px;"><?php echo $_SESSION['waktu'];?> Menit</span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5><strong>Guru</strong></h5>
                        <span style="font-size: 15px;"><?php echo $_SESSION['pembuat_soal'];?></span>
                    </td>
                </tr>   
            </table>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="alert alert-warning alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            Hi
            <strong><?php echo $_SESSION['nama_lengkap'];?></strong> jika anda telah siap untuk memulai ujian 
            silahkan tekan tombol MULAI dibawah. apabila waktu telah habis akan otomatis terinput dan anda akan dapat melihat nilai anda.<br>
            Jika terjadi masalah saat mengerjakan ujian, silahkan hubungi guru mata ujian masing - masing.
            <br>
        </div>
        <form method="post" action="<?php $_SERVER['PHP_SELF'];?>">
        <input type="hidden" name="cari_soal" value="<?php echo $_SESSION['cari_soal'];?>">
        <input type="submit" class="btn btn-danger btn-block" name="cari" value="Mulai" style="border-radius: 0px; height: 50px;">
        </form>
    </div>
</div>
</body>