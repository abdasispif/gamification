<br><br>
<div class="container">
<div class="alert alert-info alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>Note : </strong>
            Jika Status Anda Remedial, Silahkan Hubungi guru mata
            pelajaran yang remedial
            <br>
            untuk memperbaiki nilai anda!!
        </div>
	<div class="panel panel-default">
		<div class="panel-body">
			<h3>Nilai Ulangan Anda</h3>
			<?php 
			include "../config/koneksi.php";
			$sql = mysqli_query($dbconf,"SELECT * FROM t_nilai WHERE username1='$_SESSION[username]'");
			?>
			<table class="table table-hover table-bordered">
				<tr>
					<td style="background-color: #ECEFF1">Nama</td>
					<td style="background-color: #ECEFF1">Tanggal Ujian</td>
					<td style="background-color: #ECEFF1">Mata Pelajaran</td>
					<td style="background-color: #ECEFF1">kode soal</td>
					<td style="background-color: #ECEFF1">Status</td>
					<td style="background-color: #ECEFF1">Nilai</td>
					<td style="background-color: #ECEFF1">Level</td>
					<!-- <td style="background-color: #ECEFF1">Point</td> -->
				</tr>
			<?php
			while ($data = mysqli_fetch_array($sql)) {
			?>
				<tr>
					<td><?php echo $data['username1'];?></td>
					<td><?php echo $data['tanggalUjian'];?></td>
					<td><?php echo $data['mata_pelajaran'];?></td>
					<td><?php echo $data['kode_soal'];?></td>
					<td><?php if($data['nilai'] < 70.0){ echo "Remedial";} else { echo "Tidak Remedial";} ?></td>
					<td><?php echo $data['nilai'];?></td>
					<td><?php echo $data['level'];?></td>
					<!-- <td><?php echo $data['point'];?></td> -->
				</tr>
			<?php } ?>
			</table>
		</div>
	</div>
</div>