<?php
include "../config/koneksi.php";
include "../chiper/cipher-function.php";
$id  = $cipher->decrypt($_GET['id'],$key);
$get = mysqli_query($dbconf,"SELECT * FROM t_materi where id ='$id'");
$a  = mysqli_fetch_array($get);
?>
<br><br>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h3><strong>Judul Materi : </strong><?php echo $a['judul_materi']; ?></h3>
	<hr>
	<h4>
		<?php
		echo nl2br($a['isi_materi']);
		?>
	</h4>
		</div>
	</div>
</div>