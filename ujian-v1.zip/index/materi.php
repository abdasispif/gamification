<br><br>
<div class="container">
	<div class="panel panel-default">
		<div class="panel-body">
			<h3>Daftar Materi</h3>
			<?php 
			include "../config/koneksi.php";
			$no = 0;
			$sql = mysqli_query($dbconf,"SELECT * FROM t_materi");
			$no++;
			?>
			<table class="table table-bordered">
				<tr>
					<td style="background-color: #ECEFF1" width="5%">No</td>
					<td style="background-color: #ECEFF1">Judul Materi</td>
					<td align="center" style="background-color: #ECEFF1" width="10%">Action</td>
					<!-- <td style="background-color: #ECEFF1">Point</td> -->
				</tr>
			<?php
			include "../chiper/cipher-function.php";
			while ($data = mysqli_fetch_array($sql)) {
				 $id  = str_replace('+','%2B',$cipher->encrypt($data['id'],$key));
			?>
				<tr>
					<td><?php echo $no;?></td>
					<td><?php echo $data['judul_materi'];?></td>
					<td align="center">
						     <a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="View" href="beranda.php?page=detail&&id=<?php echo $id;?>">
                               <i class="fa fa-eye"></i>&nbsp; Lihat
                            </a>
					</td>

				</tr>
			<?php } ?>
			</table>
		</div>
	</div>
</div>