<?php
if (isset($_POST['kirim'])) {
include "config/koneksi.php";
$nama_lengkap = $_POST['nama_lengkap'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$username = $_POST['username'];
$password = md5($_POST['password']);
$nis = $_POST['nis'];
$kelas    = $_POST['kelas'];
$jurusan  = $_POST['jurusan'];

$sql = "INSERT INTO user (nama_lengkap,jenis_kelamin,username,password,nis,kelas,jurusan) 
        VALUES ('$nama_lengkap','$jenis_kelamin','$username','$password','$nis','$kelas','$jurusan')"; 

if(!empty($_POST['username'] and $_POST['password'])){

if (!mysqli_query($dbconf,$sql)) {
    echo "<script>alert('Gagal Input data'); window.location = 'register.php'</script>";	
} else {
     echo "<script>alert('sukses!'); window.location = 'register.php'</script>";	
 }  
} else {
    echo "<script>alert('masih ada data yang kosong'); window.location = 'register.php'</script>";	
 }
}
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ujian Online</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<?php
// DESKTOP-3K1URAQ
// include "config/aktivasi_key.php";
// $hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
// $query = mysqli_query($dbconf,"SELECT * FROM table_key WHERE hostname='$hostname'");
// $get = mysqli_fetch_array($query);
//  if ($hostname == $get['hostname']){
?>
    <div class="container" style="margin-top: 14px">
       <div class="grid">
            <div class="">
                <header class="login__header">
                    <h4>Register Siswa</h4>
                </header>
                <div class="login__body">
                    <br>
                    <form method="POST" action="">
                        <div class="form-group">
                            <input type="text" name="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required="">
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="jenis_kelamin">
                                <option>--Jenis kelamin--</option>
                                <option value="Laki - laki">Laki - laki</option>
                                <option value="Perempuan">Permpuan</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="text" name="username" class="form-control" placeholder="Username" required="">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" class="form-control" placeholder="Password" required="">
                        </div>
                         <div class="form-group">
                            <input type="text" name="nis" class="form-control" placeholder="NIS" required="">
                        </div>
                        <div class="form-group">
                            <input type="text" name="kelas" class="form-control" placeholder="Kelas Harap Isi dengan benar" required="">
                        </div>
                         <div class="form-group">
                            <input type="text" name="jurusan" class="form-control" placeholder="jurusan" required="">
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-block btn-login" value="Submit" name="kirim">
                        </div>
                        <br>
                        <footer class="login__footer">
                            <div class="col-xs-2 col-xs-offset-8">
                            <a href="index.php" class="btn btn-sm" style="font-size: 15px; color: blue;">&nbsp;Login</a>
                            </div>
                        </footer>
                    </form>
                </div>
            </div>
       </div>
    </div>
</body>
        <script src="js/jquery.js"></script>
        <script src="js/bootstrap.min.js"></script>
</html>
<?php 
// } else {
//     // include 'aktivasi.php';
// }    ?>