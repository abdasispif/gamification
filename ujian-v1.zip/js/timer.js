 $(document).ready(function() {
    
            var detik = 0;
            var menit =  <?php echo $menit ?>;
            var jam     = <?php echo $jam ?>;
            var hari    = 2;
                  
        
            function hitung() {
          
                setTimeout(hitung,1000);
  
                if(menit < 10 && jam == 0){
                    var peringatan = 'style="color:red"';
                };
  
                $('#timer').html(
                    '<h1 align="center"'+peringatan+'>Sisa waktu anda <br />' + jam + ' jam : ' + menit + ' menit : ' + detik + ' detik</h1><hr>'
                );
  
                detik --;
  
                if(detik < 0) {
                    detik = 59;
                    menit --;
  
                
                    if(menit < 0) {
                        menit = 59;
                        jam --;
  
                      
                             
                        if(jam < 0) { 
                            clearInterval(); 

                            var frmSoal = document.getElementById("frmSoal"); 
                            alert('Waktu Anda telah habis, Terima kasih sudah berkunjung.');
                            frmSoal.submit(); 
                        } 
                    } 
                } 
            }           

            hitung();
      }); 
      // ]]>