$(document).ready(function () {
  var trigger = $('.hamburger'),
      overlay = $('.overlay'),
     isClosed = false;

    trigger.click(function () {
      hamburger_cross();      
    });

    function hamburger_cross() {

      if (isClosed == true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
  });  
});

$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(document).ready(function(){
$('#myTable').DataTable();
});

$('#test').BootSideMenu({

  // 'left' or 'right'
  side: "right",

  // animation speed
  duration: 500,

  // restore last menu status on page refresh
  remember: true,

  // auto close
  autoClose: false,

  // push the whole page
  pushBody: false,

  // close on click
  closeOnClick: true,

  // width
  width: "20%",

  // icons
  icons: {
    left: 'glyphicon glyphicon-chevron-left',
    right: 'glyphicon glyphicon-chevron-right',
    down: 'glyphicon glyphicon-chevron-down'
  },

  // 'dracula', 'darkblue', 'zenburn', 'pinklady', 'somebook'
  theme: '',
  
});

  $('.some-class-name').jfontsize({
    btnMinusClasseId: '#jfontsize-m2', // Defines the class or id of the decrease button
    btnDefaultClasseId: '#jfontsize-d2', // Defines the class or id of default size button
    btnPlusClasseId: '#jfontsize-p2', // Defines the class or id of the increase button
    btnMinusMaxHits: 1, // How many times the size can be decreased
    btnPlusMaxHits: 5, // How many times the size can be increased
    sizeChange: 5 // Defines the range of change in pixels
  });

