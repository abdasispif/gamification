<?php
include "../config/koneksi.php";
include "../chiper/cipher-function.php";
$view_soal = $cipher->decrypt($_GET['kode_soal'],$key);
include "../chiper/cipher-function.php";
$tampil = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE kode_soal='$view_soal'");
$x = mysqli_fetch_array($tampil);
?>
<html>
<head>
    <link href="../css/home.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<body>
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">Mata Pelajaran <?php echo $x['mata_pelajaran'];?></h4>
					<h4 style="color: white;">Kode Soal <strong><?php echo $x['kode_soal'];?></strong></h4>
					<h4 style="color: white;">Waktu <strong><?php echo $x['waktu'];?> menit</strong></h4>
				</div>
				<div class="panel-body table-responsive">
					<table class="table">
						<thead>
							<tr>
								<td>No</td>
								<td>Soal</td>
								<td>Jawaban A</td>
								<td>Jawaban B</td>
								<td>Jawaban C</td>
								<td>Jawaban D</td>
								<td>Jawaban Benar</td>
								<td>Action</td>
							</tr>
						</thead>
						<?php 
						$tampil2 = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE kode_soal='$view_soal'");
						$no=0;
						while ($data=mysqli_fetch_array($tampil2)){
							$nosoal = str_replace('+','%2B',$cipher->encrypt($data['no'],$key));
						$no++;
						?>
						<tbody>
						<tr>
							<td><?php echo $no;?></td>
							<td><?php echo $data['soal'];?></td>
							<td><?php echo $data['a'];?></td>
							<td><?php echo $data['b'];?></td>
							<td><?php echo $data['c'];?></td>
							<td><?php echo $data['d'];?></td>
							<td><?php echo $data['jawaban'];?></td>
							<td>
								<a href="index.php?page=edit_soal&&no=<?php echo $nosoal;?>" class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                <a href="delete.php?no=<?php echo $data['no'];?>" onclick="return confirm('Apakah anda ingin menghapus soal ini?')" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
							</td>
						</tr>
						</tbody>
						<?php  }?>
					</table>
					
				</div>
			</div>
		</div>
	</div>
</body>
</html>