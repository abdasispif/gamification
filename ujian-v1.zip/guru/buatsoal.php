<?php
 // error_reporting(E_ALL & ~E_NOTICE);
if(isset($_POST['soalbuat'])){
require "../config/koneksi.php";

$ErrorForm = "";
// $kode   = md5($_POST['kode_soal']);
// $kode_potong = substr($kode,25);
$kode_soal = $_POST['kode_soal'];
$mapel  = $_POST['mata_pelajaran'];
$pembuat_soal = $_POST['pembuat_soal'];
$level = $_POST['level'];
$point = $_POST['point_level'];
$waktu = $_POST['waktu'];
$soal   = $_POST['soal'];
$jawaban_a  = $_POST['a'];
$jawaban_b  = $_POST['b'];
$jawaban_c  = $_POST['c'];
$jawaban_d  = $_POST['d'];
$jawaban_benar=$_POST['jawaban'];
switch($jawaban_benar) {
    case 1:
        $jawaban=$jawaban_a;
        // $jawab_pg_image=$target_file_1;
    break;
    case 2:
        $jawaban=$jawaban_b;
        // $jawab_pg_image=$target_file_2;
    break;
    case 3:
        $jawaban=$jawaban_c;
        // $jawab_pg_image=$target_file_3;
    break;
    case 4:
        $jawaban=$jawaban_d;
        // $jawab_pg_image=$target_file_4;
    break;
    default:
        $jawaban='';
        // $jawab_pg_image='';
    break;
}
$status = $_POST['status'];
      
$sql = "INSERT INTO t_soal (kode_soal,mata_pelajaran,pembuat_soal,level,point_level,waktu,soal,a,b,c,d,jawaban,status) VALUES ('$kode_soal','$mapel','$pembuat_soal','$level','$point_level','$waktu','$soal','$jawaban_a','$jawaban_b','$jawaban_c','$jawaban_d','$jawaban','0')";
if(!empty($_POST['soal'] and $_POST['mata_pelajaran'])){

if (!mysqli_query($dbconf,$sql)) {
    echo "<script>alert('Gagal Input data');</script>";	
} else {
     echo "<script>alert('sukses!'); window.location = 'index.php?page=lihat_soal'</script>";	
 }  
} else {
    echo "<script>alert('tolong isi semua');</script>";	
 }
}
?>
<html>
<head>
    <link href="../css/home.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
</head>
<div class="row">
<div class="col-md-12">
<div class="">
    <div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><h4 style="color: white;">Tambah Soal</h4></div>
    <div class="panel-body">
       
        <form class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
             <?php 
            include "../config/koneksi.php";
            include "../chiper/cipher-function.php";
            $kode_soal  = $cipher->decrypt($_GET['kode_soal'],$key);
            $sql = mysqli_query($dbconf,"SELECT * FROM data_soal WHERE kode_soal = '$kode_soal'");
            $get = mysqli_fetch_array($sql); ?>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Mata Pelajaran</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" name="mata_pelajaran" value="<?php echo $get['mata_pelajaran'];?>" readonly>
                </div>
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Pembuat Soal</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" readonly="readonly" name="pembuat_soal" value="<?php echo $_SESSION['username'];?>">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Level</label>
                <div class="col-sm-4">
                    <input type="text" name="level" class="form-control" value="<?php echo $get['level'];?>" readonly>
                    <input type="hidden" name="point_level" class="form-control" value="10" readonly>
                </div>
            </div>
            <!-- <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Point Level</label>
                <div class="col-sm-4">
                    <select name="level" class="form-control">
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="30">30</option>
                        <option value="40">40</option>
                        <option value="50">50</option>
                        <option value="60">60</option>
                        <option value="70">70</option>
                        <option value="80">80</option>
                        <option value="90">90</option>
                        <option value="100">100</option>
                    </select>
                    <input type="text" name="level_point" class="form-control">
                </div>
            </div> -->
            <div class="form-group">
                <input type="hidden" name="kode_soal" value="">
                <label for="inputEmail3" class="col-sm-2 control-label">Waktu Ujian</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" name="waktu" value="<?php echo $get['waktu'];?>" readonly>
                </div>
                <div class="col-sm-2">
                    <span style="color:red"><strong>*dalam hitungan menit</strong></span>
                </div>
            </div>
            <div class="form-group">
                <input type="hidden" name="kode_soal" value="">
                <label for="inputEmail3" class="col-sm-2 control-label">Kode Unik</label>
                <div class="col-sm-4">
                    <input type="text" class="form-control" name="kode_soal" value="<?php echo $get['kode_soal'];?>" readonly>
                </div>
                <div class="col-sm-4">
                    <!-- <span style="color:red"><strong>*kode harus sama untuk satu pelajaran</strong></span> -->
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Soal</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="soal" rows="3" required></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban A</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="a" rows="3" required=""></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban B</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="b" rows="3" required=""></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban C</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="c" rows="3" required=""></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Jawaban D</label>
                <div class="col-sm-6">
                    <textarea class="form-control" name="d" rows="3" required=""></textarea>
                </div>
            </div>
            <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Kunci Jawaban</label>
                <div class="col-sm-6">
                    <select name="jawaban" required class="form-control">
                    <option value="">Jawaban</option>
                    <option value="1">Jawaban A</option>
                    <option value="2">Jawaban B</option>
                    <option value="3">Jawaban C</option>
                    <option value="4">Jawaban D</option>
                    <!-- <option value="5">Pilihan 5</option> -->
                <!--    <option value="6">Gambar 1</option>
                    <option value="7">Gambar 2</option>
                    <option value="8">Gambar 3</option>
                    <option value="9">Gambar 4</option>
                    <option value="10">Gambar 5</option>
                --></select>
                </div>
            </div>
            <div class="form-group">
                <div class="col-sm-offset-2 col-sm-10">
                    <button type="submit" class="btn btn-default" name="soalbuat">Buat</button>
                </div>
            </div>
        </form>
    </div>
</div>
            <!-- <a class="fab" href="#"><i class="fa fa-dashboard fa-2x"></i></a> -->
</div>
</div>
</html>