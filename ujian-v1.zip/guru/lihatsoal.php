<?php

?>
<div class="row" >
	<div class="col-xs-12">
		<div class="">
		<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><label style="color: white; font-size: 20px;">List Soal</label>&nbsp;&nbsp;
			<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">Buat Soal</button></div>
			<div class="panel-body table-responsive">
			<?php
			// $pembuat_soal = $_SESSION['username'];
			include "../config/koneksi.php";
			// $tampil = mysqli_query($dbconf,"SELECT * FROM data_soal WHERE pembuat_soal='$_SESSION[username]'");
			// $tampil = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE pembuat_soal='$_SESSION[username]' GROUP BY kode_soal,mata_pelajaran,pembuat_soal,waktu,status HAVING count(*) > 0");
			$tampil = mysqli_query($dbconf,"SELECT * FROM data_soal where pembuat_soal='$_SESSION[username]'");
			?>
			<table id="myTable" class="table">
			<thead>
			<tr>
			<th><center>No<i class="fa fa-sort"></i></center></th>
			<th><center>Kode Soal <i class="fa fa-sort"></i></center></th>
			<th><center>jml soal <i class="fa fa-sort"></i></center></th>
			<th><center>Mata Pelajaran <i class="fa fa-sort"></i></center></th>
			<th><center>Pembuat <i class="fa fa-sort"></i></center></th>
			<th><center>Waktu <i class="fa fa-sort"></i></center></th>
			<th><center>Status <i class="fa fa-sort"></i></center></th>
			<th width="30%"><center>Tools</center></th>
			</tr>
			</thead>
			<tbody>
			<?php
			include "../chiper/cipher-function.php";
			$no = 0;
			while ($data=mysqli_fetch_array($tampil)){
			$view_soal  = str_replace('+','%2B',$cipher->encrypt($data['kode_soal'],$key));
			$query_data_soal = mysqli_query($dbconf,"SELECT * from t_soal where kode_soal='$data[kode_soal]'");
			$jml_soal = mysqli_num_rows($query_data_soal);
			$no++;
			?>
			<tr>
				<td><?php echo $no;?></td>
				<td><?php echo $data['kode_soal'];?></td>
				<td align="center"><?php echo $jml_soal;?></td>
				<td><?php echo $data['mata_pelajaran'];?></td>
				<td><?php echo $data['pembuat_soal'];?></td>
				<td><?php echo $data['waktu'];?> Menit</td>
				<td align="center"><?php if ($data['status'] == 1) { echo'<span class="label label-success">Aktif</span>'; } else if ($data['status'] == 0) { echo '<span class="label label-danger">Tidak Aktif</span>'; } ?></td>
				<td width="30%">
					<center>
					<div id="thanks">
					<a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="index.php?page=buatsoal&&kode_soal=<?php echo $view_soal;?>">
                       <i class="fa fa-edit"></i>Tambah soal
                    </a>
					<a class="btn btn-sm btn-success" data-placement="bottom" name="view_soal" data-toggle="tooltip" title="Detail" href="?page=detail_soal&kode_soal=<?php echo $view_soal; ?>">
					<i class="fa fa-eye"></i> Lihat Soal
					</a>
					<?php if ($data['status'] == 1) { ?>

					  <a class="btn btn-sm btn-danger" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="aktif_status.php?page=disable&&kode_soal=<?php echo $view_soal;?>">
                       <i class="fa fa-check-square"></i> Disable
                    </a>
					<?php } else if($data['status'] == 0) { ?>
					 <a class="btn btn-sm btn-info" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="aktif_status.php?page=enable&&kode_soal=<?php echo $view_soal;?>">
                       <i class="fa fa-check-square"></i> Enable
                    </a>
					<?php } ?>
					</div>
					</center>
				</td>
			</tr>
			<?php
			}
			?>
			</tbody>
			</table>
			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Buat Soal</h4>
      </div>
      <div class="modal-body">
        <form class="" action="proses.php?page=proses" method="post">
            <div class="form-group">
                <label for="inputEmail3" class="control-label">Mata Pelajaran</label>
                <!-- <div class="col-sm-4"> -->
                    <input type="text" class="form-control" name="mata_pelajaran">
                <!-- </div> -->
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="control-label">Pembuat Soal</label>
                <!-- <div class="col-sm-4"> -->
                    <input type="text" class="form-control" readonly="readonly" name="pembuat_soal" value="<?php echo $_SESSION['username'];?>">
                <!-- </div> -->
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="control-label">Level</label>
                <!-- <div class="col-sm-4"> -->
                    <select name="level" class="form-control">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                    </select>
                <!-- </div> -->
            </div>
            <!-- <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Point Level</label>
                <div class="col-sm-4">
                    <select name="level" class="form-control">
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="30">30</option>
                        <option value="40">40</option>
                        <option value="50">50</option>
                        <option value="60">60</option>
                        <option value="70">70</option>
                        <option value="80">80</option>
                        <option value="90">90</option>
                        <option value="100">100</option>
                    </select>
                    <input type="text" name="level_point" class="form-control">
                </div>
            </div> -->
            <div class="form-group">
                <!-- <input type="hidden" name="kode_soal" value=""> -->
                <label for="inputEmail3" class="control-label">Waktu Ujian</label>
                <span style="color:red"><strong>*dalam hitungan menit</strong></span>
                <!-- <div class="col-sm-4"> -->
                    <input type="text" class="form-control" name="waktu">
                <!-- </div> -->
                <!-- <div class="col-sm-2"> -->
                <!-- </div> -->
            </div>
            <div class="form-group">
                <!-- <input type="hidden" name="kode_soal" value=""> -->
                <label for="inputEmail3" class="control-label">Kode Unik</label>
                <span style="color:red"><strong>*kode harus sama untuk satu pelajaran</strong></span>
                <!-- <div class="col-sm-4"> -->
                    <input type="text" class="form-control" name="kode_soal">
                <!-- </div> -->
                <!-- <div class="col-sm-4"> -->
                <!-- </div> -->
            </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Buat</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </form>
      </div>
    </div>

  </div>
</div>