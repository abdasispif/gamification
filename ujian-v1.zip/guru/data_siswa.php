<div class="row">
	<div class="col-md-12">
		<div class="">
		    <div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;">
		    	<h4 style="color: white;">Data Siswa</h4>
		    </div>
		    <div class="panel-body table-responsive">
		    	<table id="myTable" class="table">
		    		<thead>
		    			<tr>
		    				<td>No</td>
		    				<td>Tanggal Ujian</td>
		    				<td>Nama Lengkap</td>
		    				<td>Username</td>
		    				<td>Ulangan</td>
		    				<td>Nilai</td>
		    				<td align="center">Tool</td>
		    			</tr>
		    		</thead>
		    		<tbody>
				    <?php
					// $pembuat_soal = $_SESSION['username'];
					include "../config/koneksi.php";
					$no = 0;
					$tampil = mysqli_query($dbconf,"SELECT * FROM t_nilai");
					while($data = mysqli_fetch_array($tampil)) {
					$no++;
					?>
					<tr>
						<td><?php echo $no;?></td>
						<td><?php echo $data['tanggalUjian'];?></td>
						<td><?php echo $data['nama_lengkap'];?></td>
						<td><?php echo $data['username1'];?></td>
						<td><?php echo $data['mata_pelajaran'];?></td>
						<td><?php echo $data['nilai'];?></td>
						<td align="center">
							<a href="reset_siswa.php?id=<?php echo $data['id'];?>" onclick="return confirm('Apakah anda yakin ingin mereset akun ini?')" class="btn btn-primary btn-sm"><i class="fa fa-refresh"></i> Reset</a>							
							<!-- <a href="" class="btn btn-primary btn-sm"></a>							 -->
						</td>
					</tr>
					<?php } ?>
		    		</tbody>
		    	</table>
		    </div>
		</div>
	</div>
</div>