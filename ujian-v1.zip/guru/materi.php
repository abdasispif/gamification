<?php

?>
<div class="row" >
	<div class="col-xs-12">
		<div class="">
		<div class="panel-heading" style="background-color: #4FC3F7; border-radius: 0px;"><label style="color: white; font-size: 20px;">Materi</label>&nbsp;&nbsp;
			<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal">Buat Materi</button></div>
			<div class="panel-body table-responsive">
			<?php
			// $pembuat_soal = $_SESSION['username'];
			include "../config/koneksi.php";
			// $tampil = mysqli_query($dbconf,"SELECT * FROM data_soal WHERE pembuat_soal='$_SESSION[username]'");
			// $tampil = mysqli_query($dbconf,"SELECT * FROM t_soal WHERE pembuat_soal='$_SESSION[username]' GROUP BY kode_soal,mata_pelajaran,pembuat_soal,waktu,status HAVING count(*) > 0");
			$tampil = mysqli_query($dbconf,"SELECT * FROM t_materi where pembuat_materi='$_SESSION[username]'");
			?>
			<table id="myTable" class="table table-hover table-striped">
                <thead>
                    <tr>
                        <td width="10%">No</td>
                        <td>Judul Materi</td>
                        <td width="20%">Action</td>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $no = 0;
                include "../chiper/cipher-function.php";
                while ($get = mysqli_fetch_array($tampil)){
                $id  = str_replace('+','%2B',$cipher->encrypt($get['id'],$key));
                $no++
                ?>
                    <tr>
                        <td><?php echo $no;?></td>
                        <td><?php echo $get['judul_materi'];?></td>
                        <td>
                            <a class="btn btn-sm btn-primary" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="index.php?page=view_materi&&id=<?php echo $id;?>">
                               <i class="fa fa-eye"></i>&nbsp;&nbsp;Lihat Materi
                            </a>
                            <a class="btn btn-sm btn-danger" data-placement="bottom" data-toggle="tooltip" title="Aktifkan" href="proses.php?page=delete_materi&&id=<?php echo $id;?>">
                               <i class="fa fa-trash"></i>&nbsp;&nbsp;Delete
                            </a>
                        </td>
                    </tr>
                <?php } ?>                    
                </tbody>
            </table>
			</div>
		</div>
	</div>
</div>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Buat Materi</h4>
      </div>
      <div class="modal-body">
        <form class="" action="proses.php?page=add_materi" method="post">
            <div class="form-group">
                <label for="inputEmail3" class="control-label">Judul Materi</label>
                <!-- <div class="col-sm-4"> -->
                    <input type="hidden" class="form-control" name="pembuat_materi" value="<?php echo $_SESSION['username'];?>">
                    <input type="text" class="form-control" name="judul_materi" required=""> 
                <!-- </div> -->
            </div>
             <div class="form-group">
                <label for="inputEmail3" class="control-label">Isi Materi</label>
                <textarea name="isi_materi" class="form-control" rows="10" required=""></textarea>
            </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Buat</button>
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </form>
      </div>
    </div>

  </div>
</div>