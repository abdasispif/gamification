<?php
include "../config/koneksi.php";
// get data data
// $exe = mysqli_query($dbconf,"SELECT * FROM ");
// $get_jml = mysqli_num_rows($exe);
// get user data
$exe2 = mysqli_query($dbconf,"SELECT * FROM t_nilai ");
$usr = mysqli_num_rows($exe2);
// get seluruh soal
$soal = mysqli_query($dbconf,"SELECT * FROM t_soal GROUP BY kode_soal,mata_pelajaran,pembuat_soal,waktu,status HAVING count(*) > 0");
$jml_soal = mysqli_num_rows($soal);
// edit admin
?>
<div class="container">
<br>
<div class="row">
	<div class="col-md-11">
		<h1>Dashboard</h1>
		<div class="alert alert-success">
		  <strong>Hallo!</strong>Selamat datang <?php echo $_SESSION['username'];?>
		</div>
		<hr>
	</div>
	<div class="col-md-3">
		<div class="panel" style="background-color: #E53935; border-radius: 0px;">
			<div class="panel-body">
				<i class="fa fa-user fa-5x white" ></i>
				<label style="float: right; font-size: 50px;" class="white"><?php echo $usr; ?></label>
			</div>
			<div style="background-color: #C62828; height: 30px; padding: 5px;">
				<label class="white">Siswa</label>
			</div>
		</div>
	</div>
	<!-- <div class="col-md-3">
		<div class="panel" style="background-color: #1E88E5; border-radius: 0px;">
			<div class="panel-body">
				<i class="fa fa-user fa-5x white" ></i>
				<label style="float: right; font-size: 50px;" class="white"><?php echo $usr; ?></label>
			</div>
			<div style="background-color: #1565C0; height: 30px; padding: 5px;">
				<label class="white">Data User</label>
			</div>
		</div>
	</div> -->
	<div class="col-md-3">
		<div class="panel" style="background-color: #3F51B5; border-radius: 0px;">
			<div class="panel-body">
				<i class="fa fa-file-text fa-5x white" ></i>
				<label style="float: right; font-size: 50px;" class="white"><?php echo $jml_soal; ?></label>
			</div>
			<div style="background-color: #303F9F; height: 30px; padding: 5px;">
				<label class="white">Mata Pelajaran</label>
			</div>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-md-4">
		<div class="panel panel-primary" style="background-color:; border-radius: 0px;">
			<div class="panel-heading"><label>Change Akun</label></div>
			<div class="panel-body">
			<?php 
			$x = mysqli_query($dbconf,"SELECT * FROM data_guru where username='$_SESSION[username]'");
			$data = mysqli_fetch_array($x);
			echo '<form method="POST" action="proses.php?page=edit_admin">
					<div class="form-group">
						<input type="hidden" class="form-control" value="'.$data["id"].'" name="id"/>
					</div>
					<div class="form-group">
						<label for="username">Nama</label>
						<input type="text" class="form-control" value="" name="nama"/>
					</div>
					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" class="form-control" value="" name="username"/>
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="text" class="form-control" value="" name="password"/>
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary btn-sm"/>
					</div>';
			?>	
			</div>
		</div>
	</div>
	<div class="col-md-4">
		<div class="panel panel-default">
			<!-- <div class="panel-heading"><label>Judul Aplikasi</label></div> -->
			<div class="panel-body">
			<div id="container"></div>
			</div>
		</div>
	</div>
</div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $("#container").simpleCalendar({
        //Defaults options below
        months: ['january','february','march','april','may','june','july','august','september','october','november','december'], //string of months starting from january
        days: ['sunday','monday','tuesday','wenesday','thursday','friday','saturday'], //string of days starting from sunday
        minDate : "YYYY-MM-DD", // minimum date
        maxDate : "YYYY-MM-DD", // maximum date
        insertEvent: true, // can insert events
        displayEvent: true, // display existing event
        fixedStartDay: true, // Week begin always by monday
        event: [], //List of event
        insertCallback : function(){} // Callback when an event is added to the calendar
    });
});
</script>