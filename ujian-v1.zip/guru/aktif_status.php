<?php

require_once("../config/koneksi.php"); 
require_once("../chiper/cipher-function.php"); 
$view_soal = $cipher->decrypt($_GET['kode_soal'],$key); 
$page = $_GET['page'];

if ($page == 'disable'){
$update = "UPDATE data_soal SET status = '0' where kode_soal='$view_soal'";
$query = mysqli_query($dbconf,$update); 

if($query){ 
	header("location:index.php?page=lihat_soal");
}
else{ 
   echo "<script>alert('gagal'); window.location = 'index.php?page=lihat_soal'</script>";
}
} 
if ($page == 'enable'){
$update = "UPDATE data_soal SET status = '1' where kode_soal='$view_soal'";
$query = mysqli_query($dbconf,$update); 

if($query){ 
	header("location:index.php?page=lihat_soal");
}
else{ 
   echo "<script>alert('gagal'); window.location = 'index.php?page=lihat_soal'</script>";
}
}

?>