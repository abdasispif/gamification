
<?php
include '../config/koneksi.php';
// menyimpan data id kedalam variabel
$no   = $_GET['no'];
// query SQL untuk insert data
$query= "DELETE from t_soal where no='$no'";
mysqli_query($dbconf,$query);
// mengalihkan ke halaman index.php
   echo "<script>alert('Berhasil dihapus'); window.location = $_SERVER[HTTP_REFERER]</script>";

?>