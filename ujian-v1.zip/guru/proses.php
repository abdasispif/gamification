<?php
include "../config/koneksi.php";
require_once("../chiper/cipher-function.php"); 
$page = $_GET['page'];

if ($page == 'edit_admin'){
	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$username = $_POST['username'];
	$password = md5($_POST['password']);
	$adm = mysqli_query($dbconf,"UPDATE data_guru SET nama='$nama',username='$username',password='$password' WHERE id='$id'");
	if ($adm) {
		echo "<script>alert('Data berhasil dirubah'); window.location = 'index.php?page=dashboard'</script>";
	} else {
		echo "<script>alert('gagal'); window.location = 'index.php?page=dashboard'</script>";
	}
}

if ($page == 'proses'){
require "../config/koneksi.php";

$ErrorForm = "";
$kode   = md5($_POST['kode_soal']);
$kode_potong = substr($kode,25);
$mapel  = $_POST['mata_pelajaran'];
$pembuat_soal = $_POST['pembuat_soal'];
$level = $_POST['level'];
// $point_level = 10;
$waktu = $_POST['waktu'];
// $status = $_POST['status'];
      

// $sql = "INSERT INTO t_soal (kode_soal,mata_pelajaran,pembuat_soal,level,point_level,waktu,soal,a,b,c,d,jawaban) VALUES ('$kode_potong','$mapel','$pembuat_soal','$level','$point_level','$waktu','$soal','$jawaban_a','$jawaban_b','$jawaban_c','$jawaban_d','$jawaban_benar')";

$sql = "INSERT INTO data_soal (kode_soal,mata_pelajaran,pembuat_soal,level,waktu) VALUES ('$kode_potong','$mapel','$pembuat_soal','$level','$waktu')";

if(!empty($_POST['mata_pelajaran'])){

if (!mysqli_query($dbconf,$sql)) {
    echo "<script>alert('Gagal Input data'); </script>";	
} else {
     echo "<script>alert('sukses!'); window.location = 'index.php?page=lihat_soal'</script>";	
 }  
} else {
    echo "<script>alert('tolong isi semua');</script>";	
 }
}

if ($page == 'add_materi'){
	
function ReplaceString($str) {
	$str_=str_replace('>', '&gt;', str_replace('<', '&lt;', str_replace('"', '&quot;', str_replace("'", "&#39;", $str))));
	return $str_; 
	}
$pembuat_materi = $_POST['pembuat_materi'];
$judul = $_POST['judul_materi'];
$isi = str_replace("!=", "<", str_replace("=!", ">", ReplaceString($_POST['isi_materi'])));
     // echo $text;

$sql = mysqli_query($dbconf,"INSERT INTO t_materi (pembuat_materi,judul_materi,isi_materi) VALUES ('$pembuat_materi','$judul','$isi')");
if ($sql){
	echo "<script>alert('sukses!'); window.location = 'index.php?page=materi'</script>";	
} else {
	     echo "<script>alert('Gagal membuat materi'); window.location = 'index.php?page=materi'</script>";	
}
}

if ($page == 'delete_materi'){
$id  = $cipher->decrypt($_GET['id'],$key);

$del = mysqli_query($dbconf,"DELETE FROM t_materi where id='$id'");
if ($del){
		echo "<script>alert('sukses!'); window.location = 'index.php?page=materi'</script>";	
} else {
	     echo "<script>alert('Gagal'); window.location = 'index.php?page=materi'</script>";	
}
}
?>